package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// LXG Studio Premium Dark Theme Palette
val StudioBlack = Color(0xFF090A0F)
val StudioDarkBg = Color(0xFF0D0F18)
val StudioSurface = Color(0xFF141724)
val StudioSurfaceElevated = Color(0xFF1B2032)
val StudioSurfaceBorder = Color(0xFF282F48)

// Vibrant accents
val StudioPurplePrimary = Color(0xFF8B5CF6)
val StudioPurpleSecondary = Color(0xFFA78BFA)
val StudioCyanAccent = Color(0xFF06B6D4)
val StudioBlueAccent = Color(0xFF3B82F6)

// Broadcast Status Colors
val StudioLiveRed = Color(0xFFFF2A55)
val StudioLiveRedGlow = Color(0x66FF2A55)
val StudioRecordAmber = Color(0xFFFFB703)
val StudioAudioGreen = Color(0xFF10B981)
val StudioAudioYellow = Color(0xFFFBBF24)

// Text and neutrals
val StudioTextPrimary = Color(0xFFF8FAFC)
val StudioTextSecondary = Color(0xFF94A3B8)
val StudioTextMuted = Color(0xFF64748B)
