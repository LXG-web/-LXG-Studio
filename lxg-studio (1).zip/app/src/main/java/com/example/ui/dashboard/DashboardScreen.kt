package com.example.ui.dashboard

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.CastConnected
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Podcasts
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.CastDestination
import com.example.data.model.DestinationEntity
import com.example.data.model.RecordingEntity
import com.example.engine.RecordingStatus
import com.example.engine.ScreenCastStatus
import com.example.engine.StreamStatus
import com.example.service.FloatingBubbleService
import com.example.ui.MainViewModel
import com.example.ui.NavigationTab
import com.example.ui.components.AudioMeterView
import com.example.ui.theme.StudioAudioGreen
import com.example.ui.theme.StudioAudioYellow
import com.example.ui.theme.StudioCyanAccent
import com.example.ui.theme.StudioDarkBg
import com.example.ui.theme.StudioLiveRed
import com.example.ui.theme.StudioPurplePrimary
import com.example.ui.theme.StudioPurpleSecondary
import com.example.ui.theme.StudioRecordAmber
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceBorder
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    onNavigateTab: (NavigationTab) -> Unit
) {
    val context = LocalContext.current
    val streamStatus by viewModel.streamStatus.collectAsState()
    val recordingStatus by viewModel.recordingStatus.collectAsState()
    val screenCastStatus by viewModel.screenCastStatus.collectAsState()
    val screenCastTelemetry by viewModel.screenCastTelemetry.collectAsState()
    val availableCastDestinations by viewModel.availableCastDestinations.collectAsState()
    val selectedCastDestination by viewModel.selectedCastDestination.collectAsState()
    val recordingDurationSec by viewModel.recordingDurationSeconds.collectAsState()
    val telemetry by viewModel.telemetry.collectAsState()
    val audioMeter by viewModel.audioMeter.collectAsState()
    val settings by viewModel.streamSettings.collectAsState()
    val destinations by viewModel.destinations.collectAsState()
    val recordings by viewModel.recordings.collectAsState()
    val storageInfo by viewModel.storageInfo.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    val isFloatingBubbleActive by viewModel.isFloatingBubbleActive.collectAsState()

    val isLive = streamStatus == StreamStatus.LIVE
    val isRecording = recordingStatus == RecordingStatus.RECORDING
    val isCasting = screenCastStatus == ScreenCastStatus.CASTING

    var showOverlayPermissionDialog by remember { mutableStateOf(false) }
    var showCastDestinationPicker by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    fun checkAndExecute(action: () -> Unit) {
        val cam = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.CAMERA
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        val mic = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (!cam || !mic) {
            permissionLauncher.launch(
                arrayOf(
                    android.Manifest.permission.CAMERA,
                    android.Manifest.permission.RECORD_AUDIO
                )
            )
        } else {
            action()
        }
    }

    fun handleFloatingBubbleToggle() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(context)) {
                showOverlayPermissionDialog = true
            } else {
                if (isFloatingBubbleActive) {
                    FloatingBubbleService.stopService(context)
                } else {
                    FloatingBubbleService.startService(context)
                }
            }
        } else {
            if (isFloatingBubbleActive) {
                FloatingBubbleService.stopService(context)
            } else {
                FloatingBubbleService.startService(context)
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioDarkBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Status Notification snack if any
            statusMessage?.let { msg ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                    border = androidx.compose.foundation.BorderStroke(1.dp, StudioCyanAccent.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sensors,
                            contentDescription = null,
                            tint = StudioCyanAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = msg,
                            fontSize = 12.sp,
                            color = StudioTextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "DISMISS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = StudioCyanAccent,
                            modifier = Modifier
                                .clickable { viewModel.clearStatusMessage() }
                                .padding(4.dp)
                        )
                    }
                }
            }
        }

        // Floating Control Bubble Quick Toggle Bar
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { handleFloatingBubbleToggle() }
                    .testTag("floating_bubble_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isFloatingBubbleActive) StudioPurplePrimary else StudioSurfaceBorder
                )
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isFloatingBubbleActive) StudioPurplePrimary.copy(alpha = 0.25f)
                                    else StudioSurface
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Layers,
                                contentDescription = null,
                                tint = if (isFloatingBubbleActive) StudioPurplePrimary else StudioCyanAccent,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Floating Control Bubble",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = StudioTextPrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(
                                            if (isFloatingBubbleActive) StudioAudioGreen.copy(0.2f)
                                            else StudioSurfaceBorder
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = if (isFloatingBubbleActive) "ON SCREEN" else "OFF",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isFloatingBubbleActive) StudioAudioGreen else StudioTextMuted
                                    )
                                }
                            }
                            Text(
                                text = "Movable overlay over games & apps with full controls",
                                fontSize = 11.sp,
                                color = StudioTextMuted
                            )
                        }
                    }

                    Switch(
                        checked = isFloatingBubbleActive,
                        onCheckedChange = { handleFloatingBubbleToggle() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = StudioPurplePrimary,
                            uncheckedThumbColor = StudioTextMuted,
                            uncheckedTrackColor = StudioSurface
                        ),
                        modifier = Modifier.testTag("floating_bubble_switch")
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Hero Stream Deck Controls (Go Live & Start Recording)
        item {
            HeroControlPanel(
                isLive = isLive,
                isRecording = isRecording,
                recordingStatus = recordingStatus,
                streamStatus = streamStatus,
                liveDurationText = telemetry.formattedDuration,
                recDurationText = String.format(Locale.US, "%02d:%02d", recordingDurationSec / 60, recordingDurationSec % 60),
                onToggleLive = { checkAndExecute { viewModel.toggleStreaming() } },
                onToggleRecord = { checkAndExecute { viewModel.toggleRecording() } },
                onPauseRecord = { viewModel.pauseRecording() },
                onResumeRecord = { viewModel.resumeRecording() },
                onTakeScreenshot = { viewModel.takeScreenshot() },
                onOpenStudio = { onNavigateTab(NavigationTab.STUDIO) }
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Dedicated Screen Cast Only Mode Card
        item {
            ScreenCastOnlyCard(
                screenCastStatus = screenCastStatus,
                telemetry = screenCastTelemetry,
                selectedDestination = selectedCastDestination,
                onStartCast = { viewModel.startScreenCast() },
                onStopCast = { viewModel.stopScreenCast() },
                onReconnect = { viewModel.reconnectScreenCast() },
                onSelectDestination = { showCastDestinationPicker = true }
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Telemetry Metrics Grid (Resolution, FPS, Bitrate, Storage)
        item {
            Text(
                text = "STREAM TELEMETRY",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = StudioTextMuted,
                letterSpacing = 1.2.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = "RESOLUTION",
                    value = settings.resolutionLabel.substringBefore(" "),
                    subtitle = "${settings.resolutionWidth}x${settings.resolutionHeight}",
                    icon = Icons.Default.Videocam,
                    accentColor = StudioPurplePrimary,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(NavigationTab.SETTINGS) }
                )
                MetricCard(
                    title = "FRAME RATE",
                    value = "${if (isLive || isCasting) telemetry.currentFps else settings.fps} FPS",
                    subtitle = "Smooth Display",
                    icon = Icons.Default.FlashOn,
                    accentColor = StudioCyanAccent,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(NavigationTab.SETTINGS) }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = "BITRATE",
                    value = if (isLive) "${telemetry.currentBitrateKbps}k" else "${settings.videoBitrateKbps}k",
                    subtitle = if (isLive) "Active stream" else "Target rate",
                    icon = Icons.Default.Sensors,
                    accentColor = if (isLive) StudioAudioGreen else StudioRecordAmber,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(NavigationTab.SETTINGS) }
                )
                MetricCard(
                    title = "STORAGE",
                    value = String.format(Locale.US, "%.1f GB", storageInfo.freeGb),
                    subtitle = "Free space",
                    icon = Icons.Default.Bookmark,
                    accentColor = StudioTextSecondary,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(NavigationTab.RECORDINGS) }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Live Audio Console
        item {
            Text(
                text = "AUDIO MONITOR",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = StudioTextMuted,
                letterSpacing = 1.2.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            AudioMeterView(
                audioMeter = audioMeter,
                isMuted = settings.isMicMuted,
                gainPercent = settings.micGainPercent,
                onToggleMute = { viewModel.toggleMicMute() },
                onGainChanged = { viewModel.setMicGain(it) }
            )
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Connected Broadcast Platforms
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "BROADCAST DESTINATIONS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioTextMuted,
                    letterSpacing = 1.2.sp
                )
                Text(
                    text = "Manage (${destinations.size})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioCyanAccent,
                    modifier = Modifier
                        .clickable { onNavigateTab(NavigationTab.DESTINATIONS) }
                        .padding(4.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    if (destinations.isEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "No streaming destinations configured.",
                                fontSize = 13.sp,
                                color = StudioTextMuted
                            )
                        }
                    } else {
                        destinations.take(3).forEach { dest ->
                            DestinationRowMini(
                                destination = dest,
                                onToggle = { viewModel.toggleDestination(dest) }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Quick Studio Actions
        item {
            Text(
                text = "QUICK STUDIO ACTIONS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = StudioTextMuted,
                letterSpacing = 1.2.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionButton(
                    label = "Studio Canvas",
                    icon = Icons.Default.Videocam,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(NavigationTab.STUDIO) }
                )
                QuickActionButton(
                    label = "Screenshot",
                    icon = Icons.Default.CameraAlt,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.takeScreenshot() }
                )
                QuickActionButton(
                    label = "Save Clip",
                    icon = Icons.Default.History,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.captureReplayBuffer() }
                )
                QuickActionButton(
                    label = "Settings",
                    icon = Icons.Default.Settings,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(NavigationTab.SETTINGS) }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Recent Recordings
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "RECENT RECORDINGS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioTextMuted,
                    letterSpacing = 1.2.sp
                )
                Text(
                    text = "View All (${recordings.size})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioCyanAccent,
                    modifier = Modifier
                        .clickable { onNavigateTab(NavigationTab.RECORDINGS) }
                        .padding(4.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            if (recordings.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = null,
                            tint = StudioTextMuted,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No recordings yet",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = StudioTextSecondary
                        )
                        Text(
                            text = "Tap 'Start Recording' or record in Studio to capture clips",
                            fontSize = 12.sp,
                            color = StudioTextMuted
                        )
                    }
                }
            } else {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(recordings.take(5)) { rec ->
                        RecentRecordingCard(
                            recording = rec,
                            onPlay = { viewModel.openPlayback(rec) }
                        )
                    }
                }
            }
        }
    }

    // Overlay Permission Explanation Dialog
    if (showOverlayPermissionDialog) {
        AlertDialog(
            onDismissRequest = { showOverlayPermissionDialog = false },
            containerColor = StudioSurfaceElevated,
            title = {
                Text(
                    text = "Overlay Permission Required",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = StudioTextPrimary
                )
            },
            text = {
                Text(
                    text = "To show the floating control bubble on top of other apps and games without interrupting your recording or broadcast, LXG Studio requires 'Display over other apps' permission.\n\nTap 'Grant Permission' to open Android settings and enable it for LXG Studio.",
                    fontSize = 13.sp,
                    color = StudioTextSecondary,
                    lineHeight = 18.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showOverlayPermissionDialog = false
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                            context.startActivity(intent)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioPurplePrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Grant Permission", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showOverlayPermissionDialog = false }) {
                    Text("Cancel", color = StudioTextSecondary)
                }
            }
        )
    }

    // Screen Cast Destination Picker Dialog
    if (showCastDestinationPicker) {
        AlertDialog(
            onDismissRequest = { showCastDestinationPicker = false },
            containerColor = StudioSurfaceElevated,
            title = {
                Text(
                    text = "Select Screen Cast Destination",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = StudioTextPrimary
                )
            },
            text = {
                Column {
                    availableCastDestinations.forEach { dest ->
                        val isSel = dest.id == selectedCastDestination.id
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable {
                                    viewModel.selectCastDestination(dest)
                                    showCastDestinationPicker = false
                                },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSel) StudioPurplePrimary.copy(alpha = 0.2f) else StudioSurface
                            ),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSel) StudioPurplePrimary else StudioSurfaceBorder
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Tv,
                                    contentDescription = null,
                                    tint = if (isSel) StudioCyanAccent else StudioTextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = dest.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = StudioTextPrimary
                                    )
                                    Text(
                                        text = "${dest.protocol} • ${dest.endpointUrl}",
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = StudioTextMuted
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCastDestinationPicker = false }) {
                    Text("Close", color = StudioCyanAccent)
                }
            }
        )
    }
}

@Composable
private fun HeroControlPanel(
    isLive: Boolean,
    isRecording: Boolean,
    recordingStatus: RecordingStatus,
    streamStatus: StreamStatus,
    liveDurationText: String,
    recDurationText: String,
    onToggleLive: () -> Unit,
    onToggleRecord: () -> Unit,
    onPauseRecord: () -> Unit,
    onResumeRecord: () -> Unit,
    onTakeScreenshot: () -> Unit,
    onOpenStudio: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("dashboard_hero_panel"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(
            1.5.dp,
            if (isLive) StudioLiveRed.copy(alpha = 0.8f) else StudioSurfaceBorder
        )
    ) {
        Column(
            modifier = Modifier.padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (isLive) "ON AIR BROADCASTING" else if (isRecording) "RECORDING IN PROGRESS" else "BROADCAST CONTROL",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isLive) StudioLiveRed else if (isRecording) StudioRecordAmber else StudioCyanAccent,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = if (isLive) "Live Stream Active" else if (isRecording) "Capturing Video" else "Studio Ready",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = StudioTextPrimary
                    )
                }

                if (isLive) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(StudioLiveRed.copy(0.2f))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = liveDurationText,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = StudioLiveRed
                        )
                    }
                } else if (isRecording) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(StudioRecordAmber.copy(0.2f))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = recDurationText,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = StudioRecordAmber
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Main Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // GO LIVE Button
                Button(
                    onClick = onToggleLive,
                    modifier = Modifier
                        .weight(1.2f)
                        .height(50.dp)
                        .testTag("go_live_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isLive) StudioLiveRed else StudioPurplePrimary
                    )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = if (isLive) Icons.Default.Stop else Icons.Default.Radio,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isLive) "END STREAM" else "GO LIVE",
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            letterSpacing = 0.8.sp,
                            color = Color.White
                        )
                    }
                }

                // RECORD Button
                OutlinedButton(
                    onClick = onToggleRecord,
                    modifier = Modifier
                        .weight(1.1f)
                        .height(50.dp)
                        .testTag("start_recording_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (isRecording) StudioRecordAmber.copy(0.2f) else Color.Transparent
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.5.dp,
                        if (isRecording) StudioRecordAmber else StudioSurfaceBorder
                    )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                            contentDescription = null,
                            tint = if (isRecording) StudioRecordAmber else StudioTextPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isRecording) "STOP REC" else "RECORD",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (isRecording) StudioRecordAmber else StudioTextPrimary
                        )
                    }
                }

                // Screenshot snapshot button
                IconButton(
                    onClick = onTakeScreenshot,
                    modifier = Modifier
                        .size(50.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(StudioSurface)
                        .border(1.dp, StudioSurfaceBorder, RoundedCornerShape(12.dp))
                        .testTag("hero_screenshot_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = "Capture Screenshot",
                        tint = StudioCyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Secondary pause/resume row when recording
            if (isRecording || recordingStatus == RecordingStatus.PAUSED) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = if (recordingStatus == RecordingStatus.PAUSED) onResumeRecord else onPauseRecord,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = StudioSurfaceBorder)
                    ) {
                        Icon(
                            imageVector = if (recordingStatus == RecordingStatus.PAUSED) Icons.Default.PlayArrow else Icons.Default.Pause,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (recordingStatus == RecordingStatus.PAUSED) "Resume Recording" else "Pause Recording",
                            fontSize = 12.sp,
                            color = StudioTextPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ScreenCastOnlyCard(
    screenCastStatus: ScreenCastStatus,
    telemetry: com.example.engine.ScreenCastTelemetry,
    selectedDestination: CastDestination,
    onStartCast: () -> Unit,
    onStopCast: () -> Unit,
    onReconnect: () -> Unit,
    onSelectDestination: () -> Unit
) {
    val isCasting = screenCastStatus == ScreenCastStatus.CASTING

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("screen_cast_only_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isCasting) StudioCyanAccent else StudioSurfaceBorder
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(if (isCasting) StudioCyanAccent.copy(0.2f) else StudioSurface),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isCasting) Icons.Default.CastConnected else Icons.Default.Cast,
                            contentDescription = null,
                            tint = if (isCasting) StudioCyanAccent else StudioTextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "SCREEN CAST ONLY",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = StudioCyanAccent,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = if (isCasting) "Mirroring Device Screen" else "Local Screen Cast Mode",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = StudioTextPrimary
                        )
                    }
                }

                if (isCasting) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(StudioCyanAccent.copy(0.2f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = telemetry.formattedDuration,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = StudioCyanAccent
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Destination Endpoint Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(StudioDarkBg)
                    .clickable { onSelectDestination() }
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = selectedDestination.name,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = StudioTextPrimary
                    )
                    Text(
                        text = selectedDestination.endpointUrl,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = StudioTextMuted
                    )
                }
                Text(
                    text = "CHANGE",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioCyanAccent
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = if (isCasting) onStopCast else onStartCast,
                    modifier = Modifier
                        .weight(1.3f)
                        .height(44.dp)
                        .testTag("toggle_screen_cast_btn"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isCasting) StudioLiveRed else StudioCyanAccent
                    )
                ) {
                    Icon(
                        imageVector = if (isCasting) Icons.Default.Stop else Icons.Default.Cast,
                        contentDescription = null,
                        tint = if (isCasting) Color.White else Color.Black,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isCasting) "STOP CAST" else "START CAST",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = if (isCasting) Color.White else Color.Black
                    )
                }

                if (isCasting) {
                    OutlinedButton(
                        onClick = onReconnect,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            tint = StudioTextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Reconnect", fontSize = 11.sp, color = StudioTextSecondary)
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clickable { onClick() }
            .testTag("metric_${title.lowercase()}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioTextMuted,
                    letterSpacing = 1.sp
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                color = StudioTextPrimary
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = StudioTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun DestinationRowMini(
    destination: DestinationEntity,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(if (destination.isEnabled) StudioAudioGreen else StudioTextMuted)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = destination.label,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = StudioTextPrimary
                )
                Text(
                    text = destination.platformName,
                    fontSize = 11.sp,
                    color = StudioTextMuted
                )
            }
        }

        Switch(
            checked = destination.isEnabled,
            onCheckedChange = { onToggle() },
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = StudioPurplePrimary,
                uncheckedThumbColor = StudioTextMuted,
                uncheckedTrackColor = StudioSurface
            ),
            modifier = Modifier.testTag("toggle_${destination.id}")
        )
    }
}

@Composable
private fun QuickActionButton(
    label: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clickable { onClick() }
            .testTag("quick_${label.lowercase().replace(" ", "_")}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = StudioCyanAccent,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = StudioTextSecondary,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun RecentRecordingCard(
    recording: RecordingEntity,
    onPlay: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(160.dp)
            .clickable { onPlay() }
            .testTag("recent_rec_${recording.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(StudioSurface),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Play",
                    tint = StudioCyanAccent,
                    modifier = Modifier.size(32.dp)
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Black.copy(0.7f))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${recording.durationMs / 1000}s",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = recording.title,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = StudioTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${recording.resolution} • ${recording.fps}fps",
                fontSize = 10.sp,
                color = StudioTextMuted
            )
        }
    }
}
