package com.example.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StreamSettings
import com.example.data.model.VideoOrientation
import com.example.ui.MainViewModel
import com.example.ui.theme.StudioAudioGreen
import com.example.ui.theme.StudioCyanAccent
import com.example.ui.theme.StudioDarkBg
import com.example.ui.theme.StudioPurplePrimary
import com.example.ui.theme.StudioRecordAmber
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceBorder
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary

@Composable
fun SettingsScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val settings by viewModel.streamSettings.collectAsState()
    val hardwareEncoders by viewModel.hardwareEncoders.collectAsState()
    val isFloatingBubbleActive by viewModel.isFloatingBubbleActive.collectAsState()
    val hasOverlayPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        Settings.canDrawOverlays(context)
    } else true

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioDarkBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 32.dp)
    ) {
        // Section: Floating Control Bubble
        item {
            SectionTitle(title = "FLOATING CONTROL BUBBLE & OVERLAY")
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(StudioPurplePrimary.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Layers,
                                    contentDescription = null,
                                    tint = StudioPurplePrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Floating Studio Overlay",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = StudioTextPrimary
                                )
                                Text(
                                    text = "Movable bubble with full broadcast & recording controls",
                                    fontSize = 11.sp,
                                    color = StudioTextMuted
                                )
                            }
                        }

                        Switch(
                            checked = settings.isFloatingBubbleEnabled,
                            onCheckedChange = { viewModel.toggleFloatingBubble() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = StudioPurplePrimary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Permission Status Indicator
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(StudioDarkBg)
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Overlay Permission: ${if (hasOverlayPermission) "GRANTED" else "REQUIRED"}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (hasOverlayPermission) StudioAudioGreen else StudioRecordAmber
                            )
                            Text(
                                text = if (hasOverlayPermission) "Allowed to draw over games & other apps" else "Enable to show controls while using other apps",
                                fontSize = 10.sp,
                                color = StudioTextMuted
                            )
                        }

                        if (!hasOverlayPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            Button(
                                onClick = {
                                    val intent = Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:${context.packageName}")
                                    )
                                    context.startActivity(intent)
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = StudioPurplePrimary),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text("Grant", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Section: Video Configuration
        item {
            SectionTitle(title = "VIDEO STREAM ENCODING")
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Resolution
                    Text(
                        text = "OUTPUT RESOLUTION",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = StudioTextMuted,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(StreamSettings.RESOLUTION_OPTIONS) { opt ->
                            val isSel = settings.resolutionLabel == opt.label
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    viewModel.updateStreamSettings(
                                        settings.copy(
                                            resolutionLabel = opt.label,
                                            resolutionWidth = opt.width,
                                            resolutionHeight = opt.height,
                                            videoBitrateKbps = opt.defaultBitrateKbps
                                        )
                                    )
                                },
                                label = { Text(text = opt.label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = StudioPurplePrimary,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.testTag("res_${opt.width}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Frame Rate (FPS)
                    Text(
                        text = "FRAME RATE (FPS)",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = StudioTextMuted,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StreamSettings.FPS_OPTIONS.forEach { fps ->
                            val isSel = settings.fps == fps
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    viewModel.updateStreamSettings(settings.copy(fps = fps))
                                },
                                label = { Text(text = "$fps FPS", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = StudioPurplePrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Bitrate Slider (Up to 16 Mbps)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TARGET BITRATE (2 TO 16 MBPS)",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = StudioTextMuted,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "${settings.videoBitrateKbps} kbps (${settings.videoBitrateKbps / 1000} Mbps)",
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = StudioCyanAccent
                        )
                    }

                    Slider(
                        value = settings.videoBitrateKbps.toFloat(),
                        onValueChange = {
                            viewModel.setBitrateOnTheFly(it.toInt())
                        },
                        valueRange = 1500f..16000f,
                        steps = 28,
                        colors = SliderDefaults.colors(
                            thumbColor = StudioCyanAccent,
                            activeTrackColor = StudioCyanAccent,
                            inactiveTrackColor = StudioSurface
                        ),
                        modifier = Modifier.testTag("bitrate_slider")
                    )

                    // Bitrate Presets: 2, 4, 6, 8, 10, 12, 16 Mbps
                    Text(
                        text = "QUICK BITRATE PRESETS",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = StudioTextMuted
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(StreamSettings.BITRATE_ADJUSTMENT_OPTIONS) { kbps ->
                            val isSel = settings.videoBitrateKbps == kbps
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    viewModel.setBitrateOnTheFly(kbps)
                                },
                                label = { Text(text = "${kbps / 1000} Mbps", fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = StudioPurplePrimary,
                                    selectedLabelColor = Color.White,
                                    containerColor = StudioDarkBg,
                                    labelColor = StudioTextSecondary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Orientation
                    Text(
                        text = "STREAM ORIENTATION",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = StudioTextMuted,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        VideoOrientation.values().forEach { orient ->
                            val isSel = settings.videoOrientation == orient
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    viewModel.updateStreamSettings(settings.copy(videoOrientation = orient))
                                },
                                label = { Text(text = orient.label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = StudioPurplePrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Section: Screen Cast Only Settings
        item {
            SectionTitle(title = "SCREEN CAST ONLY PROTOCOLS")
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Tv,
                            contentDescription = null,
                            tint = StudioCyanAccent,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Independent Screen Mirroring Engine",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = StudioTextPrimary
                            )
                            Text(
                                text = "Mirrors display without disk recording or RTMP streaming",
                                fontSize = 11.sp,
                                color = StudioTextMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    FeatureRow(
                        title = "LAN Web Browser Mirror (HTTP/WebRTC)",
                        description = "Open stream URL in any browser on the local Wi-Fi",
                        status = "Port 8080 Active",
                        isReady = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    FeatureRow(
                        title = "Wi-Fi Display (Miracast / WFD)",
                        description = "Direct peer-to-peer screen projection to Smart TVs",
                        status = "Supported",
                        isReady = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    FeatureRow(
                        title = "Local RTSP Server",
                        description = "Low-latency RTSP feed for OBS or VLC media players",
                        status = "Port 8554",
                        isReady = true
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Section: Hardware Video Encoders
        item {
            SectionTitle(title = "HARDWARE CODEC ACCELERATION")
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Memory,
                            contentDescription = null,
                            tint = StudioAudioGreen,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Device MediaCodec Hardware Encoders",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = StudioTextPrimary
                            )
                            Text(
                                text = "Queried directly from Android device MediaCodecList",
                                fontSize = 11.sp,
                                color = StudioTextMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (hardwareEncoders.isEmpty()) {
                        Text(
                            text = "H.264 (AVC) Standard Hardware Encoder Active",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            color = StudioAudioGreen
                        )
                    } else {
                        hardwareEncoders.take(4).forEach { enc ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = enc.name,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = StudioTextPrimary
                                    )
                                    Text(
                                        text = enc.mimeType,
                                        fontSize = 10.sp,
                                        color = StudioTextMuted
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(
                                            if (enc.isHardwareAccelerated) StudioAudioGreen.copy(0.2f) else StudioSurface
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = if (enc.isHardwareAccelerated) "HW ACCEL" else "SOFTWARE",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (enc.isHardwareAccelerated) StudioAudioGreen else StudioTextMuted
                                    )
                                }
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Section: Audio Settings
        item {
            SectionTitle(title = "AUDIO & MIXING")
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Audio Bitrate
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "AUDIO BITRATE (AAC)",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = StudioTextMuted
                            )
                            Text(
                                text = "${settings.audioBitrateKbps} kbps High Fidelity",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = StudioTextPrimary
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(128, 160, 192).forEach { kbps ->
                                val isSel = settings.audioBitrateKbps == kbps
                                FilterChip(
                                    selected = isSel,
                                    onClick = {
                                        viewModel.updateStreamSettings(settings.copy(audioBitrateKbps = kbps))
                                    },
                                    label = { Text(text = "${kbps}k", fontSize = 10.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = StudioPurplePrimary,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Internal Audio
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Internal Device Audio",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = StudioTextPrimary
                            )
                            Text(
                                text = "Capture gameplay and in-app sound (Android 10+)",
                                fontSize = 11.sp,
                                color = StudioTextMuted
                            )
                        }
                        Switch(
                            checked = settings.isInternalAudioEnabled,
                            onCheckedChange = {
                                viewModel.updateStreamSettings(settings.copy(isInternalAudioEnabled = it))
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = StudioPurplePrimary
                            )
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Section: Security & Privacy
        item {
            SectionTitle(title = "SECURITY & PRIVACY DISCLOSURE")
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioPurplePrimary.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = StudioPurplePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Zero-Exposure Security Guarantee",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = StudioTextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• All stream keys are encrypted inside the hardware Android Keystore using AES-256-GCM.\n• Saved stream keys are never exposed in UI or logcats.\n• Camera, Microphone, Screen-capture and Overlay permissions are requested only on explicit user action.\n• No third-party tracking, analytics, or hidden data transmission.\n• Notice: While encrypted locally, network transport security also relies on destination provider (prefer RTMPS with TLS). Absolute security cannot be claimed by any software.",
                        fontSize = 11.sp,
                        color = StudioTextSecondary,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(
        text = title,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = StudioTextMuted,
        letterSpacing = 1.2.sp
    )
}

@Composable
private fun FeatureRow(
    title: String,
    description: String,
    status: String,
    isReady: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = StudioTextPrimary
            )
            Text(
                text = description,
                fontSize = 11.sp,
                color = StudioTextMuted
            )
        }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(if (isReady) StudioAudioGreen.copy(0.15f) else StudioSurface)
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = status,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = if (isReady) StudioAudioGreen else StudioCyanAccent
            )
        }
    }
}
