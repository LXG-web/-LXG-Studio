package com.example.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Podcasts
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Podcasts
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.NavigationTab
import com.example.ui.theme.StudioCyanAccent
import com.example.ui.theme.StudioDarkBg
import com.example.ui.theme.StudioPurplePrimary
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary

private data class NavItemData(
    val tab: NavigationTab,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val tag: String
)

@Composable
fun LXGBottomNavigationBar(
    currentTab: NavigationTab,
    onTabSelected: (NavigationTab) -> Unit
) {
    val items = listOf(
        NavItemData(
            NavigationTab.HOME,
            Icons.Filled.Dashboard,
            Icons.Outlined.Dashboard,
            "nav_home"
        ),
        NavItemData(
            NavigationTab.STUDIO,
            Icons.Filled.Videocam,
            Icons.Outlined.Videocam,
            "nav_studio"
        ),
        NavItemData(
            NavigationTab.DESTINATIONS,
            Icons.Filled.Podcasts,
            Icons.Outlined.Podcasts,
            "nav_destinations"
        ),
        NavItemData(
            NavigationTab.RECORDINGS,
            Icons.Filled.VideoLibrary,
            Icons.Outlined.VideoLibrary,
            "nav_recordings"
        ),
        NavItemData(
            NavigationTab.SETTINGS,
            Icons.Filled.Settings,
            Icons.Outlined.Settings,
            "nav_settings"
        )
    )

    NavigationBar(
        containerColor = StudioSurface,
        windowInsets = WindowInsets.navigationBars,
        tonalElevation = 8.dp
    ) {
        items.forEach { item ->
            val isSelected = currentTab == item.tab
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(item.tab) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                        contentDescription = item.tab.label,
                        modifier = Modifier.size(24.dp)
                    )
                },
                label = {
                    Text(
                        text = item.tab.label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = StudioCyanAccent,
                    selectedTextColor = StudioCyanAccent,
                    indicatorColor = StudioSurfaceElevated,
                    unselectedIconColor = StudioTextMuted,
                    unselectedTextColor = StudioTextMuted
                ),
                modifier = Modifier.testTag(item.tag)
            )
        }
    }
}
