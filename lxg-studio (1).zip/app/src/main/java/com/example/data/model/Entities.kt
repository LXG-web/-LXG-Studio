package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "destinations")
data class DestinationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val platformName: String, // "YouTube Live", "Facebook Live", "Twitch", "Custom RTMP", "Custom RTMPS"
    val label: String,
    val serverUrl: String,
    val encryptedKey: String,
    val iv: String,
    val maskedKey: String,
    val isEnabled: Boolean = true,
    val lastPingMs: Long = -1,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "recordings")
data class RecordingEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val filePath: String,
    val durationMs: Long,
    val fileSizeBytes: Long,
    val resolution: String,
    val fps: Int,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "scenes")
data class SceneEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val isCameraEnabled: Boolean = true,
    val cameraLens: String = "BACK", // "BACK", "FRONT"
    val isScreenEnabled: Boolean = false,
    val isPipEnabled: Boolean = false,
    val textOverlay: String = "",
    val textOverlayPosition: String = "BOTTOM_LEFT", // "TOP_LEFT", "BOTTOM_LEFT", "BOTTOM_RIGHT"
    val showTimestamp: Boolean = true,
    val showWatermark: Boolean = true,
    val watermarkText: String = "LXG STUDIO LIVE"
)
