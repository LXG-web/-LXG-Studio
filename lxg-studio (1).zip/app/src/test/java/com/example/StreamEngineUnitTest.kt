package com.example

import com.example.data.model.StreamSettings
import com.example.data.security.KeyStoreEncryptionHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StreamEngineUnitTest {

    @Test
    fun testStreamKeyMasking() {
        val shortKey = "123"
        assertEquals("••••••••", KeyStoreEncryptionHelper.maskKey(shortKey))

        val fullKey = "live_9876543210_abcdef"
        val masked = KeyStoreEncryptionHelper.maskKey(fullKey)
        assertTrue(masked.startsWith("••••••••"))
        assertTrue(masked.endsWith("cdef"))
    }

    @Test
    fun testDefaultSettings() {
        val settings = StreamSettings()
        assertEquals(1920, settings.resolutionWidth)
        assertEquals(1080, settings.resolutionHeight)
        assertEquals(60, settings.fps)
        assertEquals(4500, settings.videoBitrateKbps)
        assertEquals("4500 kbps", settings.formattedBitrate)
    }
}
