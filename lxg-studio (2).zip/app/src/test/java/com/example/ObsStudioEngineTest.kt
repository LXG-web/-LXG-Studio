package com.example

import com.example.data.model.obs.CanvasOrientation
import com.example.data.model.obs.CanvasPreset
import com.example.data.model.obs.CanvasScaleMode
import com.example.data.model.obs.SourceType
import com.example.engine.obs.ObsStudioManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class ObsStudioEngineTest {

    private lateinit var obsManager: ObsStudioManager

    @Before
    fun setUp() {
        obsManager = ObsStudioManager()
    }

    @Test
    fun testDefaultScenesInitialized() {
        val scenes = obsManager.scenes.value
        assertTrue("Should have default scenes initialized", scenes.isNotEmpty())
        val active = obsManager.activeScene.value
        assertNotNull("Active scene should not be null", active)
        assertEquals(CanvasOrientation.HORIZONTAL_16_9, obsManager.canvasConfig.value.orientation)
    }

    @Test
    fun testOrientationSwitchToVerticalShorts() {
        obsManager.setOrientation(CanvasOrientation.VERTICAL_9_16)
        assertEquals(CanvasOrientation.VERTICAL_9_16, obsManager.canvasConfig.value.orientation)
        assertEquals(CanvasPreset.FHD_1080P_VERTICAL, obsManager.canvasConfig.value.preset)
        assertEquals(1080, obsManager.canvasConfig.value.width)
        assertEquals(1920, obsManager.canvasConfig.value.height)

        // Verify scenes are created for 9:16 layout
        val scenes = obsManager.scenes.value
        assertTrue(scenes.all { it.orientation == CanvasOrientation.VERTICAL_9_16 })
    }

    @Test
    fun testCreateDuplicateAndRenameScene() {
        val initialCount = obsManager.scenes.value.size
        obsManager.createCustomScene("Esports Tournament")
        assertEquals(initialCount + 1, obsManager.scenes.value.size)
        val newScene = obsManager.activeScene.value
        assertNotNull(newScene)
        assertEquals("Esports Tournament", newScene?.name)

        // Duplicate
        obsManager.duplicateActiveScene()
        assertEquals(initialCount + 2, obsManager.scenes.value.size)
        assertTrue(obsManager.activeScene.value?.name?.contains("Copy") == true)

        // Rename
        val idToRename = obsManager.activeScene.value!!.id
        obsManager.renameScene(idToRename, "Finals Match")
        assertEquals("Finals Match", obsManager.activeScene.value?.name)

        // Delete
        obsManager.deleteScene(idToRename)
        assertEquals(initialCount + 1, obsManager.scenes.value.size)
    }

    @Test
    fun testSourceLayeringAndVisibility() {
        val active = obsManager.activeScene.value!!
        val firstSource = active.sources.first()

        // Toggle visibility
        obsManager.toggleSourceVisibility(firstSource.id)
        val updated = obsManager.activeScene.value!!.sources.find { it.id == firstSource.id }
        assertFalse(updated!!.isVisible)

        // Toggle lock
        obsManager.toggleSourceLock(firstSource.id)
        val locked = obsManager.activeScene.value!!.sources.find { it.id == firstSource.id }
        assertTrue(locked!!.isLocked)

        // Add Source
        obsManager.addSource(SourceType.COUNTDOWN_TIMER, "Stream Timer")
        val timerSource = obsManager.activeScene.value!!.sources.find { it.type == SourceType.COUNTDOWN_TIMER }
        assertNotNull(timerSource)
        assertEquals(300, timerSource?.timerSecondsRemaining)
    }

    @Test
    fun testCanvasConfigAndSafeZones() {
        val initialSafeZones = obsManager.canvasConfig.value.showSafeZones
        obsManager.toggleSafeZones()
        assertEquals(!initialSafeZones, obsManager.canvasConfig.value.showSafeZones)

        obsManager.setScaleMode(CanvasScaleMode.FILL)
        assertEquals(CanvasScaleMode.FILL, obsManager.canvasConfig.value.scaleMode)
    }
}
