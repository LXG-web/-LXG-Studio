package com.example

import com.example.data.model.RtmpDestination
import com.example.data.model.RtmpDestinationEntity
import com.example.data.security.KeyStoreEncryptionHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class RtmpDestinationEncryptionTest {

    @Test
    fun testRtmpDestinationDataClassUrlValidation() {
        val validRtmp = RtmpDestination(
            serverUrl = "rtmp://a.rtmp.youtube.com/live2",
            streamKey = "live_secret_key_123"
        )
        assertTrue(validRtmp.isValidServerUrl())
        assertFalse(validRtmp.isRtmps)

        val validRtmps = RtmpDestination(
            serverUrl = "rtmps://live-api-s.facebook.com:443/rtmp/",
            streamKey = "fb_secret_key_456"
        )
        assertTrue(validRtmps.isValidServerUrl())
        assertTrue(validRtmps.isRtmps)

        val invalidProtocol = RtmpDestination(
            serverUrl = "http://example.com/stream",
            streamKey = "key"
        )
        assertFalse(invalidProtocol.isValidServerUrl())
    }

    @Test
    fun testStreamKeyMaskingDoesNotExposeKey() {
        val destination = RtmpDestination(
            serverUrl = "rtmp://live.twitch.tv/app/",
            streamKey = "live_user_xyz123456"
        )
        val masked = destination.maskedKey
        assertFalse(masked.contains("xyz123"))
        assertTrue(masked.startsWith("••••••••"))
        assertTrue(masked.endsWith("3456"))
    }

    @Test
    fun testFullPublishUrlComposition() {
        val destination = RtmpDestination(
            serverUrl = "rtmp://a.rtmp.youtube.com/live2",
            streamKey = "abcd-1234-efgh-5678"
        )
        assertEquals("rtmp://a.rtmp.youtube.com/live2/abcd-1234-efgh-5678", destination.getFullPublishUrl())

        val destinationTrailingSlash = RtmpDestination(
            serverUrl = "rtmps://live-api-s.facebook.com:443/rtmp/",
            streamKey = "/secretKeyHere"
        )
        assertEquals("rtmps://live-api-s.facebook.com:443/rtmp/secretKeyHere", destinationTrailingSlash.getFullPublishUrl())
    }

    @Test
    fun testToEntityEncryptsKeyWithAesGcm() {
        val originalKey = "super_confidential_stream_key_998877"
        val domain = RtmpDestination(
            id = 42L,
            platformName = "YouTube Live",
            label = "Main Channel",
            serverUrl = "rtmp://a.rtmp.youtube.com/live2",
            streamKey = originalKey,
            isEnabled = true
        )

        val entity: RtmpDestinationEntity = domain.toEntity()

        assertEquals(42L, entity.id)
        assertEquals("YouTube Live", entity.platformName)
        assertEquals("rtmp://a.rtmp.youtube.com/live2", entity.serverUrl)
        // Ensure plaintext key is NOT stored
        assertNotEquals(originalKey, entity.encryptedKey)
        assertTrue(entity.encryptedKey.isNotEmpty())
        assertTrue(entity.iv.isNotEmpty())
        assertTrue(entity.maskedKey.startsWith("••••••••"))
        assertEquals("AES/GCM/NoPadding", entity.encryptionAlgorithm)

        // Decrypt stream key and verify integrity
        val decryptedKey = entity.decryptStreamKey()
        assertEquals(originalKey, decryptedKey)

        // Reconvert to domain model
        val reconstructedDomain = entity.toDomainModel()
        assertEquals(originalKey, reconstructedDomain.streamKey)
        assertEquals(domain.serverUrl, reconstructedDomain.serverUrl)
    }

    @Test
    fun testCreateSecureFactoryMethod() {
        val rawKey = "twitch_stream_key_alpha_beta"
        val entity = RtmpDestinationEntity.createSecure(
            platformName = "Twitch",
            label = "Speedrun Stream",
            serverUrl = "rtmp://live.twitch.tv/app/",
            rawStreamKey = rawKey,
            isEnabled = true
        )

        assertNotEquals(rawKey, entity.encryptedKey)
        assertEquals(rawKey, entity.decryptStreamKey())
        assertTrue(entity.maskedKey.endsWith("beta"))
    }
}
