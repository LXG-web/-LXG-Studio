package com.example

import com.example.data.security.KeyStoreEncryptionHelper
import com.example.engine.rtmp.Amf0
import com.example.engine.rtmp.H264AvcHelper
import com.example.engine.rtmp.RtmpPacket
import com.example.engine.rtmp.RtmpUrlParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class RtmpStreamingUnitTest {

    @Test
    fun testYouTubeRtmpUrlParsing() {
        val standardYt = "rtmp://a.rtmp.youtube.com/live2"
        val key = "abcd-1234-efgh-5678"
        val parsed = RtmpUrlParser.parse(standardYt, key)

        assertFalse("Standard YouTube URL should not be RTMPS", parsed.isRtmps)
        assertEquals("a.rtmp.youtube.com", parsed.host)
        assertEquals(1935, parsed.port)
        assertEquals("live2", parsed.app)
        assertEquals("abcd-1234-efgh-5678", parsed.streamName)
        assertEquals("rtmp://a.rtmp.youtube.com:1935/live2", parsed.tcUrl)
    }

    @Test
    fun testYouTubeRtmpsUrlParsing() {
        val secureYt = "rtmps://a.rtmp.youtube.com/live2:443"
        val key = "live_sample_key_999"
        val parsed = RtmpUrlParser.parse(secureYt, key)

        assertTrue("RTMPS URL must be identified as secure", parsed.isRtmps)
        assertEquals("a.rtmp.youtube.com", parsed.host)
        assertEquals(443, parsed.port)
        assertEquals("live2", parsed.app)
        assertEquals("live_sample_key_999", parsed.streamName)
    }

    @Test
    fun testAmf0StringNumberBooleanRoundtrip() {
        val out = ByteArrayOutputStream()
        Amf0.writeString(out, "connect")
        Amf0.writeNumber(out, 1.0)
        Amf0.writeBoolean(out, true)
        Amf0.writeNull(out)

        val input = ByteArrayInputStream(out.toByteArray())
        assertEquals("connect", Amf0.readNext(input))
        assertEquals(1.0, Amf0.readNext(input))
        assertEquals(true, Amf0.readNext(input))
        assertEquals(null, Amf0.readNext(input))
    }

    @Test
    fun testAmf0ObjectSerialization() {
        val out = ByteArrayOutputStream()
        val data = mapOf(
            "app" to "live2",
            "flashVer" to "FMLE/3.0",
            "capabilities" to 31.0
        )
        Amf0.writeValue(out, data)

        val input = ByteArrayInputStream(out.toByteArray())
        val decoded = Amf0.readNext(input) as? Map<*, *>
        assertNotNull("Decoded AMF0 object should not be null", decoded)
        assertEquals("live2", decoded!!["app"])
        assertEquals("FMLE/3.0", decoded["flashVer"])
        assertEquals(31.0, decoded["capabilities"])
    }

    @Test
    fun testH264SequenceHeaderGeneration() {
        val avcHeader = H264AvcHelper.createAvcSequenceHeader()
        assertTrue("AVC header length should be at least 30 bytes", avcHeader.size >= 30)
        assertEquals(0x17.toByte(), avcHeader[0]) // Keyframe (1) + AVC (7)
        assertEquals(0x00.toByte(), avcHeader[1]) // Sequence header type (0)
        assertEquals(0x01.toByte(), avcHeader[5]) // AVCDecoderConfigurationRecord version 1
    }

    @Test
    fun testAacSequenceHeaderGeneration() {
        val aacHeader = H264AvcHelper.createAacSequenceHeader()
        assertEquals(4, aacHeader.size)
        assertEquals(0xAF.toByte(), aacHeader[0]) // AAC 44kHz Stereo
        assertEquals(0x00.toByte(), aacHeader[1]) // AAC sequence header
        assertEquals(0x12.toByte(), aacHeader[2]) // AAC-LC profile
        assertEquals(0x10.toByte(), aacHeader[3]) // 2 channels
    }

    @Test
    fun testRtmpPacketChunking() {
        val out = ByteArrayOutputStream()
        val payload = ByteArray(6000) { it.toByte() }

        // Chunk size = 4096: message should split into 2 chunks (fmt 0 and fmt 3)
        RtmpPacket.writeMessage(
            out = out,
            csid = 8,
            typeId = 9,
            streamId = 1,
            timestamp = 1000L,
            payload = payload,
            chunkSize = 4096
        )

        val writtenBytes = out.toByteArray()
        // Basic Header (1 byte) + Message Header (11 bytes) + chunk 1 (4096 bytes) + fmt 3 delimiter (1 byte) + chunk 2 (1904 bytes) = 6013 bytes
        assertEquals(6013, writtenBytes.size)

        // Read chunk format: first byte fmt 0 + csid 8: (0 shl 6) or 8 = 8
        assertEquals(8.toByte(), writtenBytes[0])
        // Second chunk basic header: (3 shl 6) or 8 = 0xC8 = -56 as Byte
        assertEquals(0xC8.toByte(), writtenBytes[12 + 4096])
    }

    @Test
    fun testDecryptedStreamKeyForRtmpBroadcast() {
        val rawKey = "live_9988776655_aabbcc"
        val encrypted = KeyStoreEncryptionHelper.encrypt(rawKey)

        // Decrypt key
        val decrypted = KeyStoreEncryptionHelper.decrypt(encrypted.cipherTextBase64, encrypted.ivBase64)
        assertEquals(rawKey, decrypted)
    }
}
