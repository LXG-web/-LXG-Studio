package com.example.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.LXGApplication
import com.example.MainActivity
import com.example.data.model.CastDestination
import com.example.data.model.StreamSettings
import com.example.engine.RecordingStatus
import com.example.engine.ScreenCastStatus
import com.example.engine.StreamStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs

class FloatingBubbleService : Service() {

    companion object {
        private const val TAG = "FloatingBubbleService"
        private const val PREFS_NAME = "lxg_floating_bubble_prefs"
        private const val KEY_LAST_X = "last_x"
        private const val KEY_LAST_Y = "last_y"

        fun startService(context: Context) {
            try {
                val intent = Intent(context, FloatingBubbleService::class.java)
                context.startService(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Error starting FloatingBubbleService", e)
            }
        }

        fun stopService(context: Context) {
            try {
                val intent = Intent(context, FloatingBubbleService::class.java)
                context.stopService(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Error stopping FloatingBubbleService", e)
            }
        }
    }

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: SharedPreferences
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var bubbleRootView: View? = null
    private var expandedRootView: View? = null

    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var expandedParams: WindowManager.LayoutParams

    private var isExpanded = false
    private val streamEngine by lazy { LXGApplication.instance.streamEngine }

    // Touch dragging tracking
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    // UI elements to update reactively
    private var bubbleStatusDot: View? = null
    private var bubbleTimerText: TextView? = null

    // Expanded view elements
    private var expandedStatusBadge: TextView? = null
    private var expandedTimerText: TextView? = null
    private var expandedModeTitle: TextView? = null

    // Tab content containers
    private var recContainer: LinearLayout? = null
    private var liveContainer: LinearLayout? = null
    private var castContainer: LinearLayout? = null

    // Selected tab: 0=Rec, 1=Live, 2=Cast
    private var selectedTabIndex = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        streamEngine.setFloatingBubbleActive(true)

        createBubbleView()
        createExpandedView()
        observeEngineStates()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        streamEngine.setFloatingBubbleActive(false)

        removeViewSafely(bubbleRootView)
        removeViewSafely(expandedRootView)
    }

    private fun removeViewSafely(view: View?) {
        if (view != null && view.isAttachedToWindow) {
            try {
                windowManager.removeView(view)
            } catch (e: Exception) {
                Log.e(TAG, "Error removing view", e)
            }
        }
    }

    private fun dpToPx(dp: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    // --- CREATE COLLAPSED BUBBLE ---
    private fun createBubbleView() {
        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val savedX = prefs.getInt(KEY_LAST_X, 60)
        val savedY = prefs.getInt(KEY_LAST_Y, 200)

        bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = savedX
            y = savedY
        }

        val bubbleLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dpToPx(6), dpToPx(6), dpToPx(6), dpToPx(6))
        }

        // Circular background card
        val innerCircle = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dpToPx(56), dpToPx(56))

            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#0F111A"))
                setStroke(dpToPx(2), Color.parseColor("#8B5CF6"))
            }
            elevation = dpToPx(8).toFloat()
        }

        // Status indicator dot
        bubbleStatusDot = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dpToPx(8), dpToPx(8)).apply {
                bottomMargin = dpToPx(2)
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#10B981"))
            }
        }
        innerCircle.addView(bubbleStatusDot)

        // LXG Crest text
        val lxgText = TextView(this).apply {
            text = "LXG"
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        innerCircle.addView(lxgText)

        // Mini timer text
        bubbleTimerText = TextView(this).apply {
            text = "STUDIO"
            textSize = 8f
            setTextColor(Color.parseColor("#94A3B8"))
            gravity = Gravity.CENTER
        }
        innerCircle.addView(bubbleTimerText)

        bubbleLayout.addView(innerCircle)
        bubbleRootView = bubbleLayout

        // Draggable Touch Listener
        bubbleLayout.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = bubbleParams.x
                    initialY = bubbleParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = (event.rawX - initialTouchX).toInt()
                    val deltaY = (event.rawY - initialTouchY).toInt()
                    bubbleParams.x = initialX + deltaX
                    bubbleParams.y = initialY + deltaY
                    windowManager.updateViewLayout(bubbleRootView, bubbleParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val deltaX = abs(event.rawX - initialTouchX)
                    val deltaY = abs(event.rawY - initialTouchY)
                    if (deltaX < 15 && deltaY < 15) {
                        // Click event -> expand
                        expandPanel()
                    } else {
                        // Save last position
                        prefs.edit().putInt(KEY_LAST_X, bubbleParams.x).putInt(KEY_LAST_Y, bubbleParams.y).apply()
                    }
                    true
                }
                else -> false
            }
        }

        windowManager.addView(bubbleRootView, bubbleParams)
    }

    // --- CREATE EXPANDED STUDIO CONTROL PANEL ---
    private fun createExpandedView() {
        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        expandedParams = WindowManager.LayoutParams(
            dpToPx(320),
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        val panelCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpToPx(16), dpToPx(14), dpToPx(16), dpToPx(16))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(16).toFloat()
                setColor(Color.parseColor("#141724"))
                setStroke(dpToPx(1), Color.parseColor("#3B4261"))
            }
            elevation = dpToPx(12).toFloat()
        }

        // Top Header: Title, Timer, Minimize, Close
        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dpToPx(10)
            }
        }

        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        expandedModeTitle = TextView(this).apply {
            text = "LXG STUDIO OVERLAY"
            textSize = 12f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#06B6D4"))
        }
        titleCol.addView(expandedModeTitle)

        expandedStatusBadge = TextView(this).apply {
            text = "READY • 1080p 60FPS"
            textSize = 10f
            setTextColor(Color.parseColor("#94A3B8"))
        }
        titleCol.addView(expandedStatusBadge)

        headerRow.addView(titleCol)

        // Timer badge
        expandedTimerText = TextView(this).apply {
            text = "00:00"
            textSize = 12f
            typeface = android.graphics.Typeface.MONOSPACE
            setTextColor(Color.WHITE)
            setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(6).toFloat()
                setColor(Color.parseColor("#1B2032"))
            }
        }
        headerRow.addView(expandedTimerText)

        // Open App button
        val appBtn = Button(this).apply {
            text = "APP"
            textSize = 10f
            setTextColor(Color.parseColor("#06B6D4"))
            background = null
            setPadding(dpToPx(6), 0, dpToPx(6), 0)
            setOnClickListener {
                val intent = Intent(this@FloatingBubbleService, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
                startActivity(intent)
            }
        }
        headerRow.addView(appBtn)

        // Minimize (-) Button
        val minBtn = Button(this).apply {
            text = "—"
            textSize = 14f
            setTextColor(Color.WHITE)
            background = null
            setPadding(dpToPx(6), 0, dpToPx(6), 0)
            setOnClickListener { collapsePanel() }
        }
        headerRow.addView(minBtn)

        // Close (X) Button
        val closeBtn = Button(this).apply {
            text = "✕"
            textSize = 14f
            setTextColor(Color.parseColor("#FF2A55"))
            background = null
            setPadding(dpToPx(6), 0, dpToPx(6), 0)
            setOnClickListener {
                stopSelf()
            }
        }
        headerRow.addView(closeBtn)

        panelCard.addView(headerRow)

        // Mode Selector Tab Row [REC] [LIVE] [SCREEN CAST]
        val tabRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(36)).apply {
                bottomMargin = dpToPx(12)
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(8).toFloat()
                setColor(Color.parseColor("#0D0F18"))
            }
            setPadding(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2))
        }

        val recTabBtn = createTabButton("● RECORD", 0)
        val liveTabBtn = createTabButton("◉ LIVE", 1)
        val castTabBtn = createTabButton("⎘ CAST ONLY", 2)

        tabRow.addView(recTabBtn)
        tabRow.addView(liveTabBtn)
        tabRow.addView(castTabBtn)
        panelCard.addView(tabRow)

        // --- TAB 1: RECORDING CONTROLS CONTAINER ---
        recContainer = createRecordingTabContainer()
        panelCard.addView(recContainer)

        // --- TAB 2: LIVE STREAMING CONTROLS CONTAINER ---
        liveContainer = createLiveStreamingTabContainer()
        liveContainer?.visibility = View.GONE
        panelCard.addView(liveContainer)

        // --- TAB 3: SCREEN CAST ONLY CONTAINER ---
        castContainer = createScreenCastTabContainer()
        castContainer?.visibility = View.GONE
        panelCard.addView(castContainer)

        expandedRootView = panelCard
    }

    private fun createTabButton(title: String, index: Int): Button {
        return Button(this).apply {
            text = title
            textSize = 10f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            setTextColor(if (selectedTabIndex == index) Color.WHITE else Color.parseColor("#94A3B8"))
            background = if (selectedTabIndex == index) {
                GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(6).toFloat()
                    setColor(Color.parseColor("#8B5CF6"))
                }
            } else null

            setOnClickListener {
                selectedTabIndex = index
                updateTabsUI()
            }
        }
    }

    private fun updateTabsUI() {
        recContainer?.visibility = if (selectedTabIndex == 0) View.VISIBLE else View.GONE
        liveContainer?.visibility = if (selectedTabIndex == 1) View.VISIBLE else View.GONE
        castContainer?.visibility = if (selectedTabIndex == 2) View.VISIBLE else View.GONE
    }

    // --- TAB 1: RECORDING PANEL ---
    private fun createRecordingTabContainer(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

            // Primary Action Row: Start/Stop, Pause/Resume, Screenshot
            val actionRow = LinearLayout(this@FloatingBubbleService).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(42)).apply {
                    bottomMargin = dpToPx(10)
                }
            }

            val toggleRecBtn = Button(this@FloatingBubbleService).apply {
                text = if (streamEngine.recordingStatus.value == RecordingStatus.RECORDING) "STOP REC" else "START REC"
                textSize = 11f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.3f).apply {
                    marginEnd = dpToPx(6)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(8).toFloat()
                    setColor(Color.parseColor("#EF233C"))
                }
                setOnClickListener {
                    if (streamEngine.recordingStatus.value == RecordingStatus.RECORDING) {
                        streamEngine.stopRecording()
                    } else {
                        streamEngine.startRecording()
                    }
                }
            }

            val pauseRecBtn = Button(this@FloatingBubbleService).apply {
                text = if (streamEngine.recordingStatus.value == RecordingStatus.PAUSED) "RESUME" else "PAUSE"
                textSize = 10f
                setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    marginEnd = dpToPx(6)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(8).toFloat()
                    setColor(Color.parseColor("#282F48"))
                }
                setOnClickListener {
                    if (streamEngine.recordingStatus.value == RecordingStatus.RECORDING) {
                        streamEngine.pauseRecording()
                    } else if (streamEngine.recordingStatus.value == RecordingStatus.PAUSED) {
                        streamEngine.resumeRecording()
                    }
                }
            }

            val screenshotBtn = Button(this@FloatingBubbleService).apply {
                text = "SNAP"
                textSize = 10f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(Color.BLACK)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.9f)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(8).toFloat()
                    setColor(Color.parseColor("#06B6D4"))
                }
                setOnClickListener {
                    streamEngine.takeScreenshot()
                }
            }

            actionRow.addView(toggleRecBtn)
            actionRow.addView(pauseRecBtn)
            actionRow.addView(screenshotBtn)
            addView(actionRow)

            // Bitrate selector: 2, 4, 6, 8, 10, 12, 16 Mbps
            val bitrateTitle = TextView(this@FloatingBubbleService).apply {
                text = "BITRATE (ADJUST ON-THE-FLY)"
                textSize = 9f
                setTextColor(Color.parseColor("#64748B"))
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            }
            addView(bitrateTitle)

            val bitrateScroll = HorizontalScrollView(this@FloatingBubbleService).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = dpToPx(4)
                    bottomMargin = dpToPx(10)
                }
            }
            val bitrateRow = LinearLayout(this@FloatingBubbleService).apply {
                orientation = LinearLayout.HORIZONTAL
            }

            listOf(2000, 4000, 6000, 8000, 10000, 12000, 16000).forEach { kbps ->
                val mbpsText = "${kbps / 1000}M"
                val bBtn = Button(this@FloatingBubbleService).apply {
                    text = mbpsText
                    textSize = 10f
                    setTextColor(Color.WHITE)
                    layoutParams = LinearLayout.LayoutParams(dpToPx(48), dpToPx(32)).apply {
                        marginEnd = dpToPx(4)
                    }
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dpToPx(6).toFloat()
                        setColor(if (streamEngine.streamSettings.value.videoBitrateKbps == kbps) Color.parseColor("#8B5CF6") else Color.parseColor("#1B2032"))
                    }
                    setOnClickListener {
                        streamEngine.setBitrateOnTheFly(kbps)
                    }
                }
                bitrateRow.addView(bBtn)
            }
            bitrateScroll.addView(bitrateRow)
            addView(bitrateScroll)

            // Mic & Audio Toggles
            val audioRow = LinearLayout(this@FloatingBubbleService).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(36))
            }

            val micBtn = Button(this@FloatingBubbleService).apply {
                text = if (streamEngine.streamSettings.value.isMicMuted) "MIC: OFF" else "MIC: ON"
                textSize = 10f
                setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    marginEnd = dpToPx(6)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(6).toFloat()
                    setColor(if (streamEngine.streamSettings.value.isMicMuted) Color.parseColor("#EF233C") else Color.parseColor("#10B981"))
                }
                setOnClickListener {
                    val current = streamEngine.streamSettings.value
                    streamEngine.updateSettings(current.copy(isMicMuted = !current.isMicMuted))
                    text = if (!current.isMicMuted) "MIC: OFF" else "MIC: ON"
                }
            }

            val internalAudioBtn = Button(this@FloatingBubbleService).apply {
                text = if (streamEngine.streamSettings.value.isInternalAudioEnabled) "SYS SOUND: ON" else "SYS SOUND: OFF"
                textSize = 10f
                setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.2f)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(6).toFloat()
                    setColor(Color.parseColor("#282F48"))
                }
                setOnClickListener {
                    val current = streamEngine.streamSettings.value
                    val updated = !current.isInternalAudioEnabled
                    streamEngine.updateSettings(current.copy(isInternalAudioEnabled = updated))
                    text = if (updated) "SYS SOUND: ON" else "SYS SOUND: OFF"
                }
            }

            audioRow.addView(micBtn)
            audioRow.addView(internalAudioBtn)
            addView(audioRow)
        }
    }

    // --- TAB 2: LIVE STREAMING PANEL ---
    private fun createLiveStreamingTabContainer(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

            // Live Go / Stop and Pause row
            val liveActionRow = LinearLayout(this@FloatingBubbleService).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(42)).apply {
                    bottomMargin = dpToPx(10)
                }
            }

            val toggleLiveBtn = Button(this@FloatingBubbleService).apply {
                text = if (streamEngine.streamStatus.value == StreamStatus.LIVE) "END STREAM" else "GO LIVE"
                textSize = 11f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.3f).apply {
                    marginEnd = dpToPx(6)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(8).toFloat()
                    setColor(if (streamEngine.streamStatus.value == StreamStatus.LIVE) Color.parseColor("#EF233C") else Color.parseColor("#8B5CF6"))
                }
                setOnClickListener {
                    if (streamEngine.streamStatus.value == StreamStatus.LIVE) {
                        streamEngine.stopStreaming()
                    } else {
                        serviceScope.launch(Dispatchers.IO) {
                            val destinations = LXGApplication.instance.database.destinationDao().getEnabledDestinations()
                            streamEngine.startStreaming(destinations)
                        }
                    }
                }
            }

            val pauseLiveBtn = Button(this@FloatingBubbleService).apply {
                text = if (streamEngine.streamStatus.value == StreamStatus.PAUSED) "RESUME" else "STANDBY"
                textSize = 10f
                setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(8).toFloat()
                    setColor(Color.parseColor("#282F48"))
                }
                setOnClickListener {
                    if (streamEngine.streamStatus.value == StreamStatus.LIVE) {
                        streamEngine.pauseStreaming()
                    } else if (streamEngine.streamStatus.value == StreamStatus.PAUSED) {
                        streamEngine.resumeStreaming()
                    }
                }
            }

            liveActionRow.addView(toggleLiveBtn)
            liveActionRow.addView(pauseLiveBtn)
            addView(liveActionRow)

            // Telemetry grid
            val telemetryBox = LinearLayout(this@FloatingBubbleService).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dpToPx(10), dpToPx(8), dpToPx(10), dpToPx(8))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(8).toFloat()
                    setColor(Color.parseColor("#0D0F18"))
                }
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dpToPx(10)
                }
            }

            val tText1 = TextView(this@FloatingBubbleService).apply {
                text = "Target Bitrate: ${streamEngine.streamSettings.value.videoBitrateKbps} kbps • 60 FPS"
                textSize = 10f
                setTextColor(Color.parseColor("#06B6D4"))
                typeface = android.graphics.Typeface.MONOSPACE
            }
            val tText2 = TextView(this@FloatingBubbleService).apply {
                text = "Dropped Frames: 0 (0.0%) • Network: EXCELLENT"
                textSize = 10f
                setTextColor(Color.parseColor("#10B981"))
                typeface = android.graphics.Typeface.MONOSPACE
            }
            telemetryBox.addView(tText1)
            telemetryBox.addView(tText2)
            addView(telemetryBox)

            // On-the-fly Bitrate Adjuster
            val bLabel = TextView(this@FloatingBubbleService).apply {
                text = "LIVE BITRATE ADJUST"
                textSize = 9f
                setTextColor(Color.parseColor("#64748B"))
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            }
            addView(bLabel)

            val bRow = LinearLayout(this@FloatingBubbleService).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(32)).apply {
                    topMargin = dpToPx(4)
                }
            }
            listOf(2500, 4500, 6000, 8000, 12000).forEach { kbps ->
                val b = Button(this@FloatingBubbleService).apply {
                    text = "${kbps / 1000}M"
                    textSize = 10f
                    setTextColor(Color.WHITE)
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                        marginEnd = dpToPx(4)
                    }
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dpToPx(6).toFloat()
                        setColor(Color.parseColor("#1B2032"))
                    }
                    setOnClickListener {
                        streamEngine.setBitrateOnTheFly(kbps)
                        tText1.text = "Target Bitrate: $kbps kbps • 60 FPS"
                    }
                }
                bRow.addView(b)
            }
            addView(bRow)

            // OBS Studio Scene Switcher
            val sceneLabel = TextView(this@FloatingBubbleService).apply {
                text = "OBS SCENE SWITCHER"
                textSize = 9f
                setTextColor(Color.parseColor("#64748B"))
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = dpToPx(8)
                }
            }
            addView(sceneLabel)

            val sceneRow = LinearLayout(this@FloatingBubbleService).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(30)).apply {
                    topMargin = dpToPx(4)
                }
            }

            val sceneNames = listOf(
                "Gameplay" to "scene_gameplay",
                "Soon" to "scene_starting_soon",
                "Chat" to "scene_just_chatting",
                "BRB" to "scene_brb",
                "Ending" to "scene_ending"
            )

            sceneNames.forEach { (name, sceneId) ->
                val sBtn = Button(this@FloatingBubbleService).apply {
                    text = name
                    textSize = 9f
                    setTextColor(Color.WHITE)
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                        marginEnd = dpToPx(3)
                    }
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dpToPx(6).toFloat()
                        setColor(Color.parseColor("#1E1B4B"))
                        setStroke(dpToPx(1), Color.parseColor("#6366F1"))
                    }
                    setOnClickListener {
                        streamEngine.obsManager.selectScene(sceneId)
                    }
                }
                sceneRow.addView(sBtn)
            }
            addView(sceneRow)

            // OBS Overlays Quick Toggle
            val overlayLabel = TextView(this@FloatingBubbleService).apply {
                text = "OVERLAYS QUICK TOGGLE"
                textSize = 9f
                setTextColor(Color.parseColor("#64748B"))
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = dpToPx(8)
                }
            }
            addView(overlayLabel)

            val overlayRow = LinearLayout(this@FloatingBubbleService).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(30)).apply {
                    topMargin = dpToPx(4)
                }
            }

            val pipToggleBtn = Button(this@FloatingBubbleService).apply {
                text = "CAM PIP"
                textSize = 9f
                setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    marginEnd = dpToPx(3)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(6).toFloat()
                    setColor(Color.parseColor("#065F46"))
                }
                setOnClickListener {
                    val active = streamEngine.obsManager.activeScene.value
                    val camSrc = active?.sources?.find { it.type == com.example.data.model.obs.SourceType.CAMERA_PIP }
                    if (camSrc != null) {
                        streamEngine.obsManager.toggleSourceVisibility(camSrc.id)
                    }
                }
            }
            overlayRow.addView(pipToggleBtn)

            val chatToggleBtn = Button(this@FloatingBubbleService).apply {
                text = "CHAT HUD"
                textSize = 9f
                setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    marginEnd = dpToPx(3)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(6).toFloat()
                    setColor(Color.parseColor("#1E293B"))
                }
                setOnClickListener {
                    val active = streamEngine.obsManager.activeScene.value
                    val chatSrc = active?.sources?.find { it.type == com.example.data.model.obs.SourceType.CHAT_OVERLAY }
                    if (chatSrc != null) {
                        streamEngine.obsManager.toggleSourceVisibility(chatSrc.id)
                    }
                }
            }
            overlayRow.addView(chatToggleBtn)

            val scoToggleBtn = Button(this@FloatingBubbleService).apply {
                text = "BT MIC"
                textSize = 9f
                setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(6).toFloat()
                    setColor(Color.parseColor("#3730A3"))
                }
                setOnClickListener {
                    streamEngine.audioRoutingManager.toggleBluetoothSco()
                }
            }
            overlayRow.addView(scoToggleBtn)
            addView(overlayRow)
        }
    }

    // --- TAB 3: SCREEN CAST ONLY PANEL ---
    private fun createScreenCastTabContainer(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

            val castInfoBox = LinearLayout(this@FloatingBubbleService).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dpToPx(10), dpToPx(8), dpToPx(10), dpToPx(8))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(8).toFloat()
                    setColor(Color.parseColor("#0D0F18"))
                }
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dpToPx(10)
                }
            }

            val cTitle = TextView(this@FloatingBubbleService).apply {
                text = "Screen Cast Only (No Recording / No RTMP)"
                textSize = 11f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
            }
            val cEndpoint = TextView(this@FloatingBubbleService).apply {
                text = "Target: ${streamEngine.selectedCastDestination.value.name}\nURL: ${streamEngine.selectedCastDestination.value.endpointUrl}"
                textSize = 10f
                setTextColor(Color.parseColor("#94A3B8"))
                typeface = android.graphics.Typeface.MONOSPACE
            }
            castInfoBox.addView(cTitle)
            castInfoBox.addView(cEndpoint)
            addView(castInfoBox)

            // Cast Action Row
            val castActionRow = LinearLayout(this@FloatingBubbleService).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(42))
            }

            val toggleCastBtn = Button(this@FloatingBubbleService).apply {
                text = if (streamEngine.screenCastStatus.value == ScreenCastStatus.CASTING) "STOP CAST" else "START CAST"
                textSize = 11f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(Color.BLACK)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.4f).apply {
                    marginEnd = dpToPx(6)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(8).toFloat()
                    setColor(if (streamEngine.screenCastStatus.value == ScreenCastStatus.CASTING) Color.parseColor("#EF233C") else Color.parseColor("#06B6D4"))
                }
                setOnClickListener {
                    if (streamEngine.screenCastStatus.value == ScreenCastStatus.CASTING) {
                        streamEngine.stopScreenCast()
                    } else {
                        streamEngine.startScreenCast()
                    }
                }
            }

            val reconnectBtn = Button(this@FloatingBubbleService).apply {
                text = "RECONNECT"
                textSize = 10f
                setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(8).toFloat()
                    setColor(Color.parseColor("#282F48"))
                }
                setOnClickListener {
                    streamEngine.reconnectScreenCast()
                }
            }

            castActionRow.addView(toggleCastBtn)
            castActionRow.addView(reconnectBtn)
            addView(castActionRow)
        }
    }

    // --- EXPAND / COLLAPSE ANIMATION & TOGGLE ---
    private fun expandPanel() {
        if (isExpanded) return
        isExpanded = true

        removeViewSafely(bubbleRootView)
        windowManager.addView(expandedRootView, expandedParams)
    }

    private fun collapsePanel() {
        if (!isExpanded) return
        isExpanded = false

        removeViewSafely(expandedRootView)
        windowManager.addView(bubbleRootView, bubbleParams)
    }

    // --- REACTIVE STATE OBSERVER ---
    private fun observeEngineStates() {
        serviceScope.launch {
            streamEngine.recordingStatus.collectLatest { status ->
                updateStatusDotsAndBadges()
            }
        }
        serviceScope.launch {
            streamEngine.streamStatus.collectLatest { status ->
                updateStatusDotsAndBadges()
            }
        }
        serviceScope.launch {
            streamEngine.screenCastStatus.collectLatest { status ->
                updateStatusDotsAndBadges()
            }
        }
        serviceScope.launch {
            streamEngine.recordingDurationSeconds.collectLatest { sec ->
                if (streamEngine.recordingStatus.value != RecordingStatus.STOPPED) {
                    val formatted = String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60)
                    bubbleTimerText?.text = formatted
                    expandedTimerText?.text = formatted
                }
            }
        }
        serviceScope.launch {
            streamEngine.telemetry.collectLatest { telem ->
                if (streamEngine.streamStatus.value == StreamStatus.LIVE) {
                    bubbleTimerText?.text = telem.formattedDuration
                    expandedTimerText?.text = telem.formattedDuration
                }
            }
        }
        serviceScope.launch {
            streamEngine.screenCastTelemetry.collectLatest { telem ->
                if (streamEngine.screenCastStatus.value == ScreenCastStatus.CASTING) {
                    bubbleTimerText?.text = telem.formattedDuration
                    expandedTimerText?.text = telem.formattedDuration
                }
            }
        }
    }

    private fun updateStatusDotsAndBadges() {
        val isRec = streamEngine.recordingStatus.value == RecordingStatus.RECORDING
        val isLive = streamEngine.streamStatus.value == StreamStatus.LIVE
        val isCast = streamEngine.screenCastStatus.value == ScreenCastStatus.CASTING

        val dotColor = when {
            isLive -> Color.parseColor("#FF2A55") // Red live
            isRec -> Color.parseColor("#FFB703") // Amber rec
            isCast -> Color.parseColor("#06B6D4") // Cyan cast
            else -> Color.parseColor("#64748B") // Muted
        }

        bubbleStatusDot?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(dotColor)
        }

        expandedModeTitle?.text = when {
            isLive -> "LXG STUDIO • LIVE BROADCAST"
            isRec -> "LXG STUDIO • LOCAL RECORDING"
            isCast -> "LXG STUDIO • SCREEN CAST ONLY"
            else -> "LXG STUDIO • OVERLAY READY"
        }

        expandedStatusBadge?.text = when {
            isLive -> "LIVE ON AIR • ${streamEngine.telemetry.value.currentBitrateKbps} kbps"
            isRec -> "RECORDING • ${streamEngine.streamSettings.value.resolutionLabel}"
            isCast -> "CASTING • ${streamEngine.selectedCastDestination.value.name}"
            else -> "READY • ${streamEngine.streamSettings.value.resolutionLabel} 60FPS"
        }
    }
}
