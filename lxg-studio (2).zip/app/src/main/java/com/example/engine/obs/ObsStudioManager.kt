package com.example.engine.obs

import com.example.data.model.obs.CanvasBackgroundType
import com.example.data.model.obs.CanvasConfig
import com.example.data.model.obs.CanvasOrientation
import com.example.data.model.obs.CanvasPreset
import com.example.data.model.obs.CanvasScaleMode
import com.example.data.model.obs.ObsScene
import com.example.data.model.obs.ObsSource
import com.example.data.model.obs.ScenePresetType
import com.example.data.model.obs.SourceType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class ObsStudioManager {

    private val _canvasConfig = MutableStateFlow(CanvasConfig())
    val canvasConfig: StateFlow<CanvasConfig> = _canvasConfig.asStateFlow()

    private val _scenes = MutableStateFlow<List<ObsScene>>(emptyList())
    val scenes: StateFlow<List<ObsScene>> = _scenes.asStateFlow()

    private val _activeScene = MutableStateFlow<ObsScene?>(null)
    val activeScene: StateFlow<ObsScene?> = _activeScene.asStateFlow()

    private val _selectedSource = MutableStateFlow<ObsSource?>(null)
    val selectedSource: StateFlow<ObsSource?> = _selectedSource.asStateFlow()

    init {
        initializeDefaultScenes()
    }

    private fun initializeDefaultScenes() {
        val initialScenes = createDefaultScenesForOrientation(CanvasOrientation.HORIZONTAL_16_9)
        _scenes.value = initialScenes
        _activeScene.value = initialScenes.firstOrNull { it.presetType == ScenePresetType.GAMEPLAY } ?: initialScenes.first()
    }

    fun setOrientation(orientation: CanvasOrientation) {
        val current = _canvasConfig.value
        if (current.orientation == orientation) return

        val newPreset = if (orientation == CanvasOrientation.HORIZONTAL_16_9) {
            CanvasPreset.FHD_1080P_HORIZONTAL
        } else {
            CanvasPreset.FHD_1080P_VERTICAL
        }

        _canvasConfig.value = current.copy(
            orientation = orientation,
            preset = newPreset,
            width = newPreset.width,
            height = newPreset.height
        )

        // Generate tailored scene templates for this orientation
        val orientationScenes = createDefaultScenesForOrientation(orientation)
        _scenes.value = orientationScenes
        _activeScene.value = orientationScenes.firstOrNull { it.presetType == ScenePresetType.GAMEPLAY } ?: orientationScenes.first()
        _selectedSource.value = null
    }

    fun setCanvasPreset(preset: CanvasPreset) {
        _canvasConfig.value = _canvasConfig.value.copy(
            preset = preset,
            width = preset.width,
            height = preset.height,
            orientation = preset.orientation
        )
    }

    fun setCustomCanvasDimensions(width: Int, height: Int) {
        val w = width.coerceIn(480, 3840)
        val h = height.coerceIn(480, 3840)
        val orientation = if (w >= h) CanvasOrientation.HORIZONTAL_16_9 else CanvasOrientation.VERTICAL_9_16
        _canvasConfig.value = _canvasConfig.value.copy(
            width = w,
            height = h,
            orientation = orientation
        )
    }

    fun toggleCameraSourceVisibility(visible: Boolean) {
        val current = _activeScene.value ?: return
        val updatedSources = current.sources.map { src ->
            if (src.type == SourceType.CAMERA_PIP) {
                src.copy(isVisible = visible)
            } else src
        }
        val updatedScene = current.copy(sources = updatedSources)
        _activeScene.value = updatedScene
        _scenes.value = _scenes.value.map { if (it.id == updatedScene.id) updatedScene else it }
    }

    fun setScaleMode(mode: CanvasScaleMode) {
        _canvasConfig.value = _canvasConfig.value.copy(scaleMode = mode)
    }

    fun setBackgroundType(type: CanvasBackgroundType) {
        _canvasConfig.value = _canvasConfig.value.copy(backgroundType = type)
    }

    fun toggleSafeZones() {
        _canvasConfig.value = _canvasConfig.value.copy(showSafeZones = !_canvasConfig.value.showSafeZones)
    }

    fun selectScene(sceneId: String) {
        val target = _scenes.value.find { it.id == sceneId }
        if (target != null) {
            _activeScene.value = target
            _selectedSource.value = null
        }
    }

    fun selectSource(source: ObsSource?) {
        _selectedSource.value = source
    }

    fun createCustomScene(name: String) {
        val newScene = ObsScene(
            id = UUID.randomUUID().toString(),
            name = name.ifBlank { "New Scene ${_scenes.value.size + 1}" },
            presetType = ScenePresetType.CUSTOM,
            orientation = _canvasConfig.value.orientation,
            sources = listOf(
                ObsSource(
                    id = UUID.randomUUID().toString(),
                    name = "Screen Source",
                    type = SourceType.SCREEN_CAPTURE,
                    xPercent = 0.0f,
                    yPercent = 0.0f,
                    widthPercent = 1.0f,
                    heightPercent = 1.0f
                ),
                ObsSource(
                    id = UUID.randomUUID().toString(),
                    name = "Logo Watermark",
                    type = SourceType.IMAGE_LOGO,
                    textContent = "LXG STUDIO LIVE",
                    xPercent = 0.04f,
                    yPercent = 0.04f,
                    widthPercent = 0.25f,
                    heightPercent = 0.08f
                )
            )
        )
        _scenes.value = _scenes.value + newScene
        _activeScene.value = newScene
    }

    fun duplicateActiveScene() {
        val current = _activeScene.value ?: return
        val duplicated = current.copy(
            id = UUID.randomUUID().toString(),
            name = "${current.name} (Copy)",
            sources = current.sources.map { it.copy(id = UUID.randomUUID().toString()) }
        )
        _scenes.value = _scenes.value + duplicated
        _activeScene.value = duplicated
    }

    fun deleteScene(sceneId: String) {
        if (_scenes.value.size <= 1) return // Keep at least one scene
        val remaining = _scenes.value.filter { it.id != sceneId }
        _scenes.value = remaining
        if (_activeScene.value?.id == sceneId) {
            _activeScene.value = remaining.first()
        }
    }

    fun renameScene(sceneId: String, newName: String) {
        _scenes.value = _scenes.value.map {
            if (it.id == sceneId) it.copy(name = newName) else it
        }
        if (_activeScene.value?.id == sceneId) {
            _activeScene.value = _activeScene.value?.copy(name = newName)
        }
    }

    // Source manipulation
    fun toggleSourceVisibility(sourceId: String) {
        updateActiveSceneSources { sources ->
            sources.map {
                if (it.id == sourceId) it.copy(isVisible = !it.isVisible) else it
            }
        }
    }

    fun toggleSourceLock(sourceId: String) {
        updateActiveSceneSources { sources ->
            sources.map {
                if (it.id == sourceId) it.copy(isLocked = !it.isLocked) else it
            }
        }
    }

    fun removeSource(sourceId: String) {
        updateActiveSceneSources { sources ->
            sources.filter { it.id != sourceId }
        }
        if (_selectedSource.value?.id == sourceId) {
            _selectedSource.value = null
        }
    }

    fun addSource(type: SourceType, customName: String? = null) {
        val isVertical = _canvasConfig.value.orientation == CanvasOrientation.VERTICAL_9_16
        val newSource = when (type) {
            SourceType.SCREEN_CAPTURE -> ObsSource(
                id = UUID.randomUUID().toString(),
                name = customName ?: "Screen Capture",
                type = type,
                xPercent = 0.0f,
                yPercent = 0.0f,
                widthPercent = 1.0f,
                heightPercent = 1.0f
            )
            SourceType.CAMERA_PIP -> ObsSource(
                id = UUID.randomUUID().toString(),
                name = customName ?: "Facecam PIP",
                type = type,
                xPercent = if (isVertical) 0.65f else 0.72f,
                yPercent = if (isVertical) 0.72f else 0.65f,
                widthPercent = if (isVertical) 0.30f else 0.25f,
                heightPercent = if (isVertical) 0.20f else 0.28f,
                shapeType = "ROUNDED"
            )
            SourceType.CHAT_OVERLAY -> ObsSource(
                id = UUID.randomUUID().toString(),
                name = customName ?: "Live Chat Box",
                type = type,
                xPercent = if (isVertical) 0.05f else 0.05f,
                yPercent = if (isVertical) 0.65f else 0.55f,
                widthPercent = if (isVertical) 0.55f else 0.30f,
                heightPercent = if (isVertical) 0.25f else 0.35f,
                opacity = 0.85f
            )
            SourceType.ALERT_BOX -> ObsSource(
                id = UUID.randomUUID().toString(),
                name = customName ?: "Stream Alerts",
                type = type,
                xPercent = if (isVertical) 0.10f else 0.35f,
                yPercent = 0.12f,
                widthPercent = if (isVertical) 0.80f else 0.30f,
                heightPercent = 0.10f,
                textContent = "★ Alex subscribed with Prime!"
            )
            SourceType.COUNTDOWN_TIMER -> ObsSource(
                id = UUID.randomUUID().toString(),
                name = customName ?: "Countdown Timer",
                type = type,
                xPercent = 0.35f,
                yPercent = 0.40f,
                widthPercent = 0.30f,
                heightPercent = 0.12f,
                timerSecondsRemaining = 300
            )
            SourceType.VIEWER_COUNTER -> ObsSource(
                id = UUID.randomUUID().toString(),
                name = customName ?: "Viewer Counter",
                type = type,
                xPercent = if (isVertical) 0.65f else 0.80f,
                yPercent = 0.04f,
                widthPercent = 0.18f,
                heightPercent = 0.06f,
                textContent = "LIVE 1.4k"
            )
            SourceType.TEXT_LABEL -> ObsSource(
                id = UUID.randomUUID().toString(),
                name = customName ?: "Text Overlay",
                type = type,
                xPercent = 0.05f,
                yPercent = if (isVertical) 0.88f else 0.88f,
                widthPercent = 0.45f,
                heightPercent = 0.06f,
                textContent = "@LXG_Studio | Live"
            )
            SourceType.IMAGE_LOGO -> ObsSource(
                id = UUID.randomUUID().toString(),
                name = customName ?: "Logo Watermark",
                type = type,
                xPercent = 0.04f,
                yPercent = 0.04f,
                widthPercent = 0.25f,
                heightPercent = 0.06f,
                textContent = "LXG STUDIO"
            )
            SourceType.BROWSER_WIDGET -> ObsSource(
                id = UUID.randomUUID().toString(),
                name = customName ?: "Browser Widget",
                type = type,
                xPercent = 0.1f,
                yPercent = 0.2f,
                widthPercent = 0.8f,
                heightPercent = 0.3f,
                targetUrl = "https://streamlabs.com/alertbox"
            )
            else -> ObsSource(
                id = UUID.randomUUID().toString(),
                name = customName ?: type.displayName,
                type = type,
                xPercent = 0.2f,
                yPercent = 0.2f,
                widthPercent = 0.4f,
                heightPercent = 0.2f
            )
        }

        updateActiveSceneSources { it + newSource }
        _selectedSource.value = newSource
    }

    fun bringSourceForward(sourceId: String) {
        updateActiveSceneSources { sources ->
            val index = sources.indexOfFirst { it.id == sourceId }
            if (index != -1 && index < sources.size - 1) {
                val mutable = sources.toMutableList()
                val item = mutable.removeAt(index)
                mutable.add(index + 1, item)
                mutable
            } else sources
        }
    }

    fun sendSourceBackward(sourceId: String) {
        updateActiveSceneSources { sources ->
            val index = sources.indexOfFirst { it.id == sourceId }
            if (index > 0) {
                val mutable = sources.toMutableList()
                val item = mutable.removeAt(index)
                mutable.add(index - 1, item)
                mutable
            } else sources
        }
    }

    fun updateSourceTransform(
        sourceId: String,
        newXPercent: Float,
        newYPercent: Float,
        newWidthPercent: Float,
        newHeightPercent: Float
    ) {
        updateActiveSceneSources { sources ->
            sources.map {
                if (it.id == sourceId && !it.isLocked) {
                    val updated = it.copy(
                        xPercent = newXPercent.coerceIn(0.0f, 0.95f),
                        yPercent = newYPercent.coerceIn(0.0f, 0.95f),
                        widthPercent = newWidthPercent.coerceIn(0.05f, 1.0f),
                        heightPercent = newHeightPercent.coerceIn(0.05f, 1.0f)
                    )
                    if (_selectedSource.value?.id == sourceId) {
                        _selectedSource.value = updated
                    }
                    updated
                } else it
            }
        }
    }

    fun updateSourceProperties(
        sourceId: String,
        text: String? = null,
        opacity: Float? = null,
        shapeType: String? = null,
        imageUri: String? = null,
        fontSizeSp: Int? = null,
        textColorHex: String? = null,
        backgroundColorHex: String? = null,
        textAlignment: String? = null
    ) {
        updateActiveSceneSources { sources ->
            sources.map {
                if (it.id == sourceId) {
                    val updated = it.copy(
                        textContent = text ?: it.textContent,
                        opacity = opacity ?: it.opacity,
                        shapeType = shapeType ?: it.shapeType,
                        imageUri = imageUri ?: it.imageUri,
                        fontSizeSp = fontSizeSp ?: it.fontSizeSp,
                        textColorHex = textColorHex ?: it.textColorHex,
                        backgroundColorHex = backgroundColorHex ?: it.backgroundColorHex,
                        textAlignment = textAlignment ?: it.textAlignment
                    )
                    if (_selectedSource.value?.id == sourceId) {
                        _selectedSource.value = updated
                    }
                    updated
                } else it
            }
        }
    }

    private fun updateActiveSceneSources(updater: (List<ObsSource>) -> List<ObsSource>) {
        val current = _activeScene.value ?: return
        val updatedSources = updater(current.sources)
        val updatedScene = current.copy(sources = updatedSources)
        _activeScene.value = updatedScene
        _scenes.value = _scenes.value.map {
            if (it.id == updatedScene.id) updatedScene else it
        }
    }

    private fun createDefaultScenesForOrientation(orientation: CanvasOrientation): List<ObsScene> {
        val isVertical = orientation == CanvasOrientation.VERTICAL_9_16

        // 1. Gameplay Scene
        val gameplayScene = ObsScene(
            id = "scene_gameplay",
            name = "Gameplay + Facecam",
            presetType = ScenePresetType.GAMEPLAY,
            orientation = orientation,
            sources = listOf(
                ObsSource(
                    id = "src_screen",
                    name = "Screen Capture",
                    type = SourceType.SCREEN_CAPTURE,
                    xPercent = 0.0f,
                    yPercent = 0.0f,
                    widthPercent = 1.0f,
                    heightPercent = 1.0f
                ),
                ObsSource(
                    id = "src_camera_pip",
                    name = "Camera PIP",
                    type = SourceType.CAMERA_PIP,
                    xPercent = if (isVertical) 0.66f else 0.73f,
                    yPercent = if (isVertical) 0.70f else 0.65f,
                    widthPercent = if (isVertical) 0.30f else 0.24f,
                    heightPercent = if (isVertical) 0.22f else 0.28f,
                    shapeType = "ROUNDED"
                ),
                ObsSource(
                    id = "src_chat_hud",
                    name = "Live Chat HUD",
                    type = SourceType.CHAT_OVERLAY,
                    xPercent = 0.04f,
                    yPercent = if (isVertical) 0.68f else 0.60f,
                    widthPercent = if (isVertical) 0.58f else 0.28f,
                    heightPercent = if (isVertical) 0.24f else 0.32f,
                    opacity = 0.85f
                ),
                ObsSource(
                    id = "src_watermark",
                    name = "LXG Watermark",
                    type = SourceType.IMAGE_LOGO,
                    textContent = "LXG STUDIO LIVE",
                    xPercent = 0.03f,
                    yPercent = 0.03f,
                    widthPercent = if (isVertical) 0.35f else 0.22f,
                    heightPercent = 0.05f
                ),
                ObsSource(
                    id = "src_viewers",
                    name = "Viewer Count",
                    type = SourceType.VIEWER_COUNTER,
                    textContent = "LIVE 2.1k",
                    xPercent = if (isVertical) 0.68f else 0.82f,
                    yPercent = 0.03f,
                    widthPercent = if (isVertical) 0.28f else 0.15f,
                    heightPercent = 0.05f
                )
            )
        )

        // 2. Starting Soon Scene
        val startingSoonScene = ObsScene(
            id = "scene_starting_soon",
            name = "Starting Soon",
            presetType = ScenePresetType.STARTING_SOON,
            orientation = orientation,
            sources = listOf(
                ObsSource(
                    id = "src_bg_starting",
                    name = "Cyber Backdrop",
                    type = SourceType.BACKGROUND,
                    xPercent = 0.0f,
                    yPercent = 0.0f,
                    widthPercent = 1.0f,
                    heightPercent = 1.0f
                ),
                ObsSource(
                    id = "src_timer_starting",
                    name = "Countdown 05:00",
                    type = SourceType.COUNTDOWN_TIMER,
                    xPercent = if (isVertical) 0.15f else 0.30f,
                    yPercent = if (isVertical) 0.40f else 0.38f,
                    widthPercent = if (isVertical) 0.70f else 0.40f,
                    heightPercent = 0.15f,
                    timerSecondsRemaining = 300
                ),
                ObsSource(
                    id = "src_title_starting",
                    name = "Stream Title",
                    type = SourceType.TEXT_LABEL,
                    textContent = "STREAM STARTING SOON • STAY TUNED",
                    xPercent = if (isVertical) 0.08f else 0.20f,
                    yPercent = if (isVertical) 0.32f else 0.28f,
                    widthPercent = if (isVertical) 0.84f else 0.60f,
                    heightPercent = 0.08f,
                    textColorHex = "#38BDF8"
                ),
                ObsSource(
                    id = "src_social_starting",
                    name = "Social Links",
                    type = SourceType.TEXT_LABEL,
                    textContent = "Follow @LXG_Studio on Twitch & YouTube",
                    xPercent = if (isVertical) 0.08f else 0.25f,
                    yPercent = if (isVertical) 0.58f else 0.60f,
                    widthPercent = if (isVertical) 0.84f else 0.50f,
                    heightPercent = 0.06f
                )
            )
        )

        // 3. Just Chatting Scene
        val justChattingScene = ObsScene(
            id = "scene_just_chatting",
            name = "Just Chatting",
            presetType = ScenePresetType.JUST_CHATTING,
            orientation = orientation,
            sources = listOf(
                ObsSource(
                    id = "src_full_cam",
                    name = "Main Camera",
                    type = SourceType.CAMERA_PIP,
                    xPercent = 0.0f,
                    yPercent = 0.0f,
                    widthPercent = if (isVertical) 1.0f else 0.70f,
                    heightPercent = if (isVertical) 0.60f else 1.0f,
                    shapeType = "RECTANGLE"
                ),
                ObsSource(
                    id = "src_chat_wide",
                    name = "Full Chat Stream",
                    type = SourceType.CHAT_OVERLAY,
                    xPercent = if (isVertical) 0.05f else 0.72f,
                    yPercent = if (isVertical) 0.62f else 0.05f,
                    widthPercent = if (isVertical) 0.90f else 0.26f,
                    heightPercent = if (isVertical) 0.35f else 0.90f,
                    opacity = 0.9f
                ),
                ObsSource(
                    id = "src_watermark_chat",
                    name = "Watermark",
                    type = SourceType.IMAGE_LOGO,
                    textContent = "LXG TALK LIVE",
                    xPercent = 0.03f,
                    yPercent = 0.03f,
                    widthPercent = 0.25f,
                    heightPercent = 0.05f
                )
            )
        )

        // 4. Be Right Back Scene
        val brbScene = ObsScene(
            id = "scene_brb",
            name = "Be Right Back",
            presetType = ScenePresetType.BE_RIGHT_BACK,
            orientation = orientation,
            sources = listOf(
                ObsSource(
                    id = "src_brb_bg",
                    name = "Intermission Backdrop",
                    type = SourceType.BACKGROUND,
                    xPercent = 0.0f,
                    yPercent = 0.0f,
                    widthPercent = 1.0f,
                    heightPercent = 1.0f
                ),
                ObsSource(
                    id = "src_brb_title",
                    name = "BRB Notice",
                    type = SourceType.TEXT_LABEL,
                    textContent = "BE RIGHT BACK • AUDIO MUTED",
                    xPercent = if (isVertical) 0.10f else 0.25f,
                    yPercent = 0.45f,
                    widthPercent = if (isVertical) 0.80f else 0.50f,
                    heightPercent = 0.10f,
                    textColorHex = "#F59E0B"
                )
            )
        )

        // 5. Ending Screen Scene
        val endingScene = ObsScene(
            id = "scene_ending",
            name = "Ending Screen",
            presetType = ScenePresetType.ENDING_SCREEN,
            orientation = orientation,
            sources = listOf(
                ObsSource(
                    id = "src_ending_bg",
                    name = "End Backdrop",
                    type = SourceType.BACKGROUND,
                    xPercent = 0.0f,
                    yPercent = 0.0f,
                    widthPercent = 1.0f,
                    heightPercent = 1.0f
                ),
                ObsSource(
                    id = "src_ending_text",
                    name = "Thanks for Watching",
                    type = SourceType.TEXT_LABEL,
                    textContent = "THANKS FOR WATCHING! • GG",
                    xPercent = if (isVertical) 0.08f else 0.20f,
                    yPercent = 0.40f,
                    widthPercent = if (isVertical) 0.84f else 0.60f,
                    heightPercent = 0.10f,
                    textColorHex = "#A855F7"
                ),
                ObsSource(
                    id = "src_ending_credits",
                    name = "Credits / Socials",
                    type = SourceType.TEXT_LABEL,
                    textContent = "Stream produced with LXG Studio Mobile",
                    xPercent = if (isVertical) 0.10f else 0.25f,
                    yPercent = 0.54f,
                    widthPercent = if (isVertical) 0.80f else 0.50f,
                    heightPercent = 0.06f
                )
            )
        )

        return listOf(gameplayScene, startingSoonScene, justChattingScene, brbScene, endingScene)
    }
}
