package com.example.engine.rtmp

import android.util.Log
import com.example.data.model.StreamSettings
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.Random
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

class RtmpSession(
    private val serverUrl: String,
    private val streamKey: String,
    private val settings: StreamSettings,
    private val onStatusUpdate: (status: String) -> Unit,
    private val onError: (errorMsg: String) -> Unit,
    private val onConnected: () -> Unit
) {
    private val TAG = "RtmpSession"
    private var socket: Socket? = null
    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null

    @Volatile
    private var isRunning = false

    var totalBytesSent: Long = 0
        private set
    var currentBitrateKbps: Int = 0
        private set
    var droppedFrames: Int = 0
        private set

    private var targetStreamId = 1
    private val chunkSize = 4096

    fun start() {
        isRunning = true
        try {
            val endpoint = RtmpUrlParser.parse(serverUrl, streamKey)
            if (endpoint.streamName.isBlank()) {
                val err = "Stream Key is empty. Please enter your YouTube / RTMP Stream Key in the Destinations tab."
                onError(err)
                return
            }

            onStatusUpdate("Connecting to ${endpoint.host}:${endpoint.port} (${if (endpoint.isRtmps) "RTMPS" else "RTMP"})...")

            // 1. Establish Socket Connection
            val s = if (endpoint.isRtmps) {
                val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
                val ssl = factory.createSocket() as SSLSocket
                try {
                    val params = ssl.sslParameters
                    params.serverNames = listOf(SNIHostName(endpoint.host))
                    ssl.sslParameters = params
                } catch (t: Throwable) {
                    Log.w(TAG, "SNI config skipped: ${t.message}")
                }
                ssl.connect(InetSocketAddress(endpoint.host, endpoint.port), 8000)
                ssl.startHandshake()
                ssl
            } else {
                val plain = Socket()
                plain.connect(InetSocketAddress(endpoint.host, endpoint.port), 8000)
                plain
            }

            s.soTimeout = 8000
            s.tcpNoDelay = true
            socket = s
            val inp = s.getInputStream()
            val out = s.getOutputStream()
            inputStream = inp
            outputStream = out

            // 2. RTMP Handshake
            onStatusUpdate("Performing RTMP Handshake with ${endpoint.host}...")
            performHandshake(inp, out)

            // 3. Set Chunk Size (4096 bytes)
            sendSetChunkSize(out, chunkSize)

            // 4. Send AMF0 'connect' command
            onStatusUpdate("Sending connect command to app '${endpoint.app}'...")
            sendConnectCommand(out, endpoint)

            // 5. Read response to connect
            readConnectResponse(inp)

            // 6. Send FMLE compatibility commands
            sendFmlePublishCommands(out, endpoint.streamName)

            // 7. Send 'createStream'
            sendCreateStream(out)
            targetStreamId = readCreateStreamResponse(inp)

            // 8. Send 'publish'
            onStatusUpdate("Publishing stream on ${endpoint.host}...")
            sendPublish(out, targetStreamId, endpoint.streamName)
            readPublishResponse(inp)

            // 9. Send Metadata (@setDataFrame / onMetaData)
            sendMetadata(out, targetStreamId)

            // 10. Send AVC / AAC Sequence Headers
            sendSequenceHeaders(out, targetStreamId)

            onStatusUpdate("LIVE! RTMP stream established successfully.")
            onConnected()

            // 11. Media packet streaming loop
            runStreamingLoop(out, targetStreamId)

        } catch (e: Exception) {
            Log.e(TAG, "RTMP Session exception", e)
            val friendlyMsg = when (e) {
                is java.net.UnknownHostException -> "Unknown Host: Cannot resolve ${e.message}. Check your internet connection."
                is SocketTimeoutException -> "Connection timed out connecting to $serverUrl."
                is java.net.ConnectException -> "Connection refused by $serverUrl (Port blocked or server offline)."
                else -> e.localizedMessage ?: "RTMP broadcast failed."
            }
            onError(friendlyMsg)
        } finally {
            close()
        }
    }

    private fun performHandshake(input: InputStream, output: OutputStream) {
        // C0 (1 byte: 0x03) + C1 (1536 bytes)
        val c0c1 = ByteArray(1537)
        c0c1[0] = 0x03
        // 4 bytes timestamp = 0
        // 4 bytes zero = 0
        Random().nextBytes(c0c1)
        c0c1[0] = 0x03
        c0c1[1] = 0
        c0c1[2] = 0
        c0c1[3] = 0
        c0c1[4] = 0
        c0c1[5] = 0
        c0c1[6] = 0
        c0c1[7] = 0
        c0c1[8] = 0
        output.write(c0c1)
        output.flush()

        // Read S0 (1 byte)
        val s0 = input.read()
        if (s0 != 0x03) {
            throw IllegalStateException("Invalid RTMP handshake version: $s0 (expected 3)")
        }

        // Read S1 (1536 bytes)
        val s1 = ByteArray(1536)
        readFully(input, s1)

        // Read S2 (1536 bytes)
        val s2 = ByteArray(1536)
        readFully(input, s2)

        // Send C2 (1536 bytes: echoing S1)
        output.write(s1)
        output.flush()
    }

    private fun sendSetChunkSize(out: OutputStream, size: Int) {
        val payload = ByteArray(4)
        payload[0] = ((size shr 24) and 0xFF).toByte()
        payload[1] = ((size shr 16) and 0xFF).toByte()
        payload[2] = ((size shr 8) and 0xFF).toByte()
        payload[3] = (size and 0xFF).toByte()

        // Type 1 = Set Chunk Size, csid = 2, streamId = 0
        RtmpPacket.writeMessage(out, csid = 2, typeId = 1, streamId = 0, timestamp = 0, payload = payload, chunkSize = size)
    }

    private fun sendConnectCommand(out: OutputStream, endpoint: ParsedRtmpEndpoint) {
        val amfOut = ByteArrayOutputStream()
        Amf0.writeString(amfOut, "connect")
        Amf0.writeNumber(amfOut, 1.0) // Transaction ID 1

        val commandObj = linkedMapOf<String, Any?>(
            "app" to endpoint.app,
            "flashVer" to "FMLE/3.0 (compatible; FMSc/1.0)",
            "swfUrl" to "",
            "tcUrl" to endpoint.tcUrl,
            "fmsVer" to "FMS/3,0,1,123",
            "capabilities" to 31.0,
            "audioCodecs" to 3191.0,
            "videoCodecs" to 252.0,
            "videoFunction" to 1.0
        )
        Amf0.writeValue(amfOut, commandObj)

        val payload = amfOut.toByteArray()
        // csid = 3, typeId = 20 (AMF0 Command)
        RtmpPacket.writeMessage(out, csid = 3, typeId = 20, streamId = 0, timestamp = 0, payload = payload, chunkSize = chunkSize)
    }

    private fun readConnectResponse(input: InputStream) {
        val maxAttempts = 12
        var attempt = 0
        while (isRunning && attempt < maxAttempts) {
            attempt++
            val msg = RtmpPacket.readMessage(input, currentChunkSize = 128) ?: continue

            // Type 20 = AMF0 Command
            if (msg.typeId == 20) {
                val bais = ByteArrayInputStream(msg.payload)
                val cmdName = Amf0.readNext(bais) as? String
                val transactionId = (Amf0.readNext(bais) as? Number)?.toDouble() ?: 0.0

                if (cmdName == "_result" && transactionId == 1.0) {
                    val props = Amf0.readNext(bais) as? Map<*, *>
                    val info = Amf0.readNext(bais) as? Map<*, *>
                    val code = (info?.get("code") ?: props?.get("code"))?.toString()
                    if (code != null && code.contains("Success", ignoreCase = true)) {
                        return
                    } else if (code != null) {
                        throw IllegalStateException("Connect rejected: $code")
                    }
                    return
                } else if (cmdName == "_error") {
                    val info = Amf0.readNext(bais)
                    throw IllegalStateException("Connect error from server: $info")
                }
            }
        }
    }

    private fun sendFmlePublishCommands(out: OutputStream, streamName: String) {
        // releaseStream
        val amf1 = ByteArrayOutputStream()
        Amf0.writeString(amf1, "releaseStream")
        Amf0.writeNumber(amf1, 2.0)
        Amf0.writeNull(amf1)
        Amf0.writeString(amf1, streamName)
        RtmpPacket.writeMessage(out, csid = 3, typeId = 20, streamId = 0, timestamp = 0, payload = amf1.toByteArray(), chunkSize = chunkSize)

        // FCPublish
        val amf2 = ByteArrayOutputStream()
        Amf0.writeString(amf2, "FCPublish")
        Amf0.writeNumber(amf2, 3.0)
        Amf0.writeNull(amf2)
        Amf0.writeString(amf2, streamName)
        RtmpPacket.writeMessage(out, csid = 3, typeId = 20, streamId = 0, timestamp = 0, payload = amf2.toByteArray(), chunkSize = chunkSize)
    }

    private fun sendCreateStream(out: OutputStream) {
        val amfOut = ByteArrayOutputStream()
        Amf0.writeString(amfOut, "createStream")
        Amf0.writeNumber(amfOut, 4.0) // Transaction ID 4
        Amf0.writeNull(amfOut)
        RtmpPacket.writeMessage(out, csid = 3, typeId = 20, streamId = 0, timestamp = 0, payload = amfOut.toByteArray(), chunkSize = chunkSize)
    }

    private fun readCreateStreamResponse(input: InputStream): Int {
        val maxAttempts = 10
        var attempt = 0
        while (isRunning && attempt < maxAttempts) {
            attempt++
            val msg = RtmpPacket.readMessage(input, currentChunkSize = 128) ?: continue
            if (msg.typeId == 20) {
                val bais = ByteArrayInputStream(msg.payload)
                val cmdName = Amf0.readNext(bais) as? String
                val transactionId = (Amf0.readNext(bais) as? Number)?.toDouble() ?: 0.0

                if (cmdName == "_result" && transactionId == 4.0) {
                    Amf0.readNext(bais) // null
                    val streamIdNum = (Amf0.readNext(bais) as? Number)?.toInt() ?: 1
                    return streamIdNum
                }
            }
        }
        return 1
    }

    private fun sendPublish(out: OutputStream, streamId: Int, streamName: String) {
        val amfOut = ByteArrayOutputStream()
        Amf0.writeString(amfOut, "publish")
        Amf0.writeNumber(amfOut, 5.0)
        Amf0.writeNull(amfOut)
        Amf0.writeString(amfOut, streamName)
        Amf0.writeString(amfOut, "live")
        RtmpPacket.writeMessage(out, csid = 3, typeId = 20, streamId = streamId, timestamp = 0, payload = amfOut.toByteArray(), chunkSize = chunkSize)
    }

    private fun readPublishResponse(input: InputStream) {
        val maxAttempts = 10
        var attempt = 0
        while (isRunning && attempt < maxAttempts) {
            attempt++
            val msg = RtmpPacket.readMessage(input, currentChunkSize = 128) ?: continue
            if (msg.typeId == 20) {
                val bais = ByteArrayInputStream(msg.payload)
                val cmdName = Amf0.readNext(bais) as? String
                if (cmdName == "onStatus") {
                    Amf0.readNext(bais) // transaction ID or null
                    Amf0.readNext(bais) // null
                    val info = Amf0.readNext(bais) as? Map<*, *>
                    val code = info?.get("code")?.toString() ?: ""
                    if (code == "NetStream.Publish.Start") {
                        return
                    } else if (code == "NetStream.Publish.BadName") {
                        throw IllegalArgumentException("YouTube rejected Stream Key (NetStream.Publish.BadName). Please check your Stream Key.")
                    } else if (code.contains("Failed", ignoreCase = true)) {
                        throw IllegalStateException("Publish failed: $code")
                    }
                    return
                }
            }
        }
    }

    private fun sendMetadata(out: OutputStream, streamId: Int) {
        val amfOut = ByteArrayOutputStream()
        Amf0.writeString(amfOut, "@setDataFrame")
        Amf0.writeString(amfOut, "onMetaData")

        val meta = linkedMapOf<String, Any?>(
            "duration" to 0.0,
            "width" to settings.resolutionWidth.toDouble(),
            "height" to settings.resolutionHeight.toDouble(),
            "videodatarate" to settings.videoBitrateKbps.toDouble(),
            "framerate" to settings.fps.toDouble(),
            "videocodecid" to 7.0, // AVC
            "audiodatarate" to 128.0,
            "audiosamplerate" to 44100.0,
            "audiosamplesize" to 16.0,
            "stereo" to true,
            "audiocodecid" to 10.0 // AAC
        )
        Amf0.writeEcmaArray(amfOut, meta)

        // Type 18 = AMF0 Data message, csid = 4
        RtmpPacket.writeMessage(out, csid = 4, typeId = 18, streamId = streamId, timestamp = 0, payload = amfOut.toByteArray(), chunkSize = chunkSize)
    }

    private fun sendSequenceHeaders(out: OutputStream, streamId: Int) {
        // 1. AVC Sequence Header
        val avcHeader = H264AvcHelper.createAvcSequenceHeader()
        RtmpPacket.writeMessage(out, csid = 8, typeId = 9, streamId = streamId, timestamp = 0, payload = avcHeader, chunkSize = chunkSize)
        totalBytesSent += avcHeader.size

        // 2. AAC Sequence Header
        val aacHeader = H264AvcHelper.createAacSequenceHeader()
        RtmpPacket.writeMessage(out, csid = 9, typeId = 8, streamId = streamId, timestamp = 0, payload = aacHeader, chunkSize = chunkSize)
        totalBytesSent += aacHeader.size
    }

    private fun runStreamingLoop(out: OutputStream, streamId: Int) {
        var frameIndex = 0
        var sampleIndex = 0
        val targetFps = settings.fps.coerceIn(24, 60)
        val frameIntervalMs = (1000L / targetFps)
        val startTime = System.currentTimeMillis()
        var lastBitrateCalcTime = startTime
        var bytesSinceLastCalc = 0L

        while (isRunning) {
            val now = System.currentTimeMillis()
            val timestamp = now - startTime

            // 1. Send Video Frame (Keyframe every 60 frames, otherwise P-frame)
            val isKeyframe = (frameIndex % 60 == 0)
            val nalu = H264AvcHelper.createSyntheticSlice(isKeyframe, frameIndex)
            val videoTag = H264AvcHelper.createVideoTag(isKeyframe, nalu)

            try {
                RtmpPacket.writeMessage(out, csid = 8, typeId = 9, streamId = streamId, timestamp = timestamp, payload = videoTag, chunkSize = chunkSize)
                totalBytesSent += videoTag.size
                bytesSinceLastCalc += videoTag.size
            } catch (e: Exception) {
                droppedFrames++
                if (!isRunning) break
                throw e
            }

            // 2. Send Audio Frame (Every alternate frame)
            if (frameIndex % 2 == 0) {
                val aacRaw = H264AvcHelper.createSyntheticAacFrame(sampleIndex++)
                val audioTag = H264AvcHelper.createAudioTag(aacRaw)
                try {
                    RtmpPacket.writeMessage(out, csid = 9, typeId = 8, streamId = streamId, timestamp = timestamp, payload = audioTag, chunkSize = chunkSize)
                    totalBytesSent += audioTag.size
                    bytesSinceLastCalc += audioTag.size
                } catch (e: Exception) {
                    // audio dropped
                }
            }

            frameIndex++

            // Calculate instantaneous bitrate every second
            if (now - lastBitrateCalcTime >= 1000L) {
                val deltaSec = (now - lastBitrateCalcTime) / 1000.0
                currentBitrateKbps = ((bytesSinceLastCalc * 8) / (deltaSec * 1000.0)).toInt()
                bytesSinceLastCalc = 0L
                lastBitrateCalcTime = now
            }

            val sleepTime = frameIntervalMs - (System.currentTimeMillis() - now)
            if (sleepTime > 0) {
                Thread.sleep(sleepTime)
            }
        }
    }

    private fun readFully(input: InputStream, buffer: ByteArray) {
        var total = 0
        while (total < buffer.size) {
            val r = input.read(buffer, total, buffer.size - total)
            if (r == -1) throw IllegalStateException("Unexpected end of stream during handshake")
            total += r
        }
    }

    fun close() {
        isRunning = false
        try {
            socket?.close()
        } catch (ignored: Exception) {}
        socket = null
        inputStream = null
        outputStream = null
    }
}
