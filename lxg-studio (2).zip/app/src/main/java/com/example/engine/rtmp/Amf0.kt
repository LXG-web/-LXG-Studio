package com.example.engine.rtmp

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream

/**
 * Clean AMF0 (Action Message Format 0) Serializer and Deserializer for RTMP commands and metadata.
 */
object Amf0 {
    const val TYPE_NUMBER: Byte = 0x00
    const val TYPE_BOOLEAN: Byte = 0x01
    const val TYPE_STRING: Byte = 0x02
    const val TYPE_OBJECT: Byte = 0x03
    const val TYPE_NULL: Byte = 0x05
    const val TYPE_UNDEFINED: Byte = 0x06
    const val TYPE_ECMA_ARRAY: Byte = 0x08
    const val TYPE_OBJECT_END: Byte = 0x09
    const val TYPE_STRICT_ARRAY: Byte = 0x0A

    fun writeString(out: OutputStream, str: String) {
        out.write(TYPE_STRING.toInt())
        val bytes = str.toByteArray(Charsets.UTF_8)
        out.write((bytes.size shr 8) and 0xFF)
        out.write(bytes.size and 0xFF)
        out.write(bytes)
    }

    fun writeNumber(out: OutputStream, value: Double) {
        out.write(TYPE_NUMBER.toInt())
        val bits = java.lang.Double.doubleToLongBits(value)
        for (i in 7 downTo 0) {
            out.write(((bits shr (i * 8)) and 0xFF).toInt())
        }
    }

    fun writeBoolean(out: OutputStream, value: Boolean) {
        out.write(TYPE_BOOLEAN.toInt())
        out.write(if (value) 1 else 0)
    }

    fun writeNull(out: OutputStream) {
        out.write(TYPE_NULL.toInt())
    }

    fun writeObjectStart(out: OutputStream) {
        out.write(TYPE_OBJECT.toInt())
    }

    fun writeProperty(out: OutputStream, key: String, value: Any?) {
        val keyBytes = key.toByteArray(Charsets.UTF_8)
        out.write((keyBytes.size shr 8) and 0xFF)
        out.write(keyBytes.size and 0xFF)
        out.write(keyBytes)
        writeValue(out, value)
    }

    fun writeObjectEnd(out: OutputStream) {
        out.write(0x00)
        out.write(0x00)
        out.write(TYPE_OBJECT_END.toInt())
    }

    fun writeValue(out: OutputStream, value: Any?) {
        when (value) {
            null -> writeNull(out)
            is String -> writeString(out, value)
            is Number -> writeNumber(out, value.toDouble())
            is Boolean -> writeBoolean(out, value)
            is Map<*, *> -> {
                writeObjectStart(out)
                for ((k, v) in value) {
                    if (k != null) {
                        writeProperty(out, k.toString(), v)
                    }
                }
                writeObjectEnd(out)
            }
            else -> writeString(out, value.toString())
        }
    }

    fun writeEcmaArray(out: OutputStream, properties: Map<String, Any?>) {
        out.write(TYPE_ECMA_ARRAY.toInt())
        val count = properties.size
        out.write((count shr 24) and 0xFF)
        out.write((count shr 16) and 0xFF)
        out.write((count shr 8) and 0xFF)
        out.write(count and 0xFF)

        for ((k, v) in properties) {
            writeProperty(out, k, v)
        }
        writeObjectEnd(out)
    }

    fun readNext(input: InputStream): Any? {
        val typeInt = input.read()
        if (typeInt == -1) return null
        val type = typeInt.toByte()

        return when (type) {
            TYPE_NUMBER -> readNumber(input)
            TYPE_BOOLEAN -> readBoolean(input)
            TYPE_STRING -> readString(input)
            TYPE_OBJECT -> readObject(input)
            TYPE_NULL, TYPE_UNDEFINED -> null
            TYPE_ECMA_ARRAY -> readEcmaArray(input)
            TYPE_STRICT_ARRAY -> readStrictArray(input)
            else -> null
        }
    }

    fun readString(input: InputStream): String {
        val lenHigh = input.read()
        val lenLow = input.read()
        if (lenHigh == -1 || lenLow == -1) return ""
        val length = (lenHigh shl 8) or lenLow
        val buffer = ByteArray(length)
        var readTotal = 0
        while (readTotal < length) {
            val r = input.read(buffer, readTotal, length - readTotal)
            if (r == -1) break
            readTotal += r
        }
        return String(buffer, 0, readTotal, Charsets.UTF_8)
    }

    fun readNumber(input: InputStream): Double {
        var bits = 0L
        for (i in 0..7) {
            val b = input.read()
            if (b == -1) return 0.0
            bits = (bits shl 8) or (b.toLong() and 0xFF)
        }
        return java.lang.Double.longBitsToDouble(bits)
    }

    fun readBoolean(input: InputStream): Boolean {
        val b = input.read()
        return b != 0 && b != -1
    }

    fun readObject(input: InputStream): Map<String, Any?> {
        val map = mutableMapOf<String, Any?>()
        while (true) {
            val lenHigh = input.read()
            val lenLow = input.read()
            if (lenHigh == -1 || lenLow == -1) break
            val keyLength = (lenHigh shl 8) or lenLow
            if (keyLength == 0) {
                val endMarker = input.read()
                if (endMarker == TYPE_OBJECT_END.toInt()) {
                    break
                }
            }
            val keyBuffer = ByteArray(keyLength)
            var read = 0
            while (read < keyLength) {
                val r = input.read(keyBuffer, read, keyLength - read)
                if (r == -1) break
                read += r
            }
            val key = String(keyBuffer, 0, read, Charsets.UTF_8)
            val value = readNext(input)
            map[key] = value
        }
        return map
    }

    fun readEcmaArray(input: InputStream): Map<String, Any?> {
        // Skip 4-byte count
        input.read()
        input.read()
        input.read()
        input.read()
        return readObject(input)
    }

    fun readStrictArray(input: InputStream): List<Any?> {
        val count = ((input.read() shl 24) or (input.read() shl 16) or (input.read() shl 8) or input.read())
        val list = mutableListOf<Any?>()
        for (i in 0 until count.coerceAtMost(100)) {
            list.add(readNext(input))
        }
        return list
    }
}
