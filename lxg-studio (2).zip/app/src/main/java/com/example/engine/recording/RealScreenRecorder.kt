package com.example.engine.recording

import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import com.example.engine.rtmp.H264AvcHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.nio.ByteBuffer

class RealScreenRecorder(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val TAG = "RealScreenRecorder"

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var mediaCodec: MediaCodec? = null
    private var mediaMuxer: MediaMuxer? = null
    private var inputSurface: Surface? = null
    private var recordingJob: Job? = null

    @Volatile
    private var isRecording = false
    private var muxerStarted = false
    private var videoTrackIndex = -1

    var currentOutputFile: File? = null
        private set

    fun startRecording(
        resultCode: Int,
        resultData: Intent?,
        width: Int = 1280,
        height: Int = 720,
        dpi: Int = 320,
        bitrateBps: Int = 5_000_000,
        fps: Int = 30,
        outputFile: File,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        if (isRecording) {
            onError("Recording is already in progress")
            return
        }

        try {
            currentOutputFile = outputFile
            if (!outputFile.exists()) {
                outputFile.parentFile?.mkdirs()
                outputFile.createNewFile()
            }

            // Ensure dimensions are even (required by H.264 encoders)
            val encWidth = if (width % 2 == 0) width else width - 1
            val encHeight = if (height % 2 == 0) height else height - 1

            // 1. Create MediaFormat for H.264
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, encWidth, encHeight).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrateBps)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1) // 1 keyframe every second
                setInteger(MediaFormat.KEY_CAPTURE_RATE, fps)
                setInteger(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 1000000 / fps)
            }

            // 2. Initialize MediaCodec Encoder
            val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surface = encoder.createInputSurface()
            encoder.start()
            mediaCodec = encoder
            inputSurface = surface

            // 3. Initialize MediaMuxer
            mediaMuxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxerStarted = false
            videoTrackIndex = -1

            // 4. Connect MediaProjection if token was provided
            if (resultData != null && resultCode == android.app.Activity.RESULT_OK) {
                try {
                    val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    val projection = projectionManager.getMediaProjection(resultCode, resultData)
                    mediaProjection = projection

                    virtualDisplay = projection?.createVirtualDisplay(
                        "LXG_VirtualDisplay",
                        encWidth,
                        encHeight,
                        dpi,
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                        surface,
                        null,
                        null
                    )
                } catch (pe: Exception) {
                    Log.w(TAG, "VirtualDisplay creation note: ${pe.message}")
                }
            }

            isRecording = true
            onSuccess()

            // 5. Run Muxer encoding loop in background
            recordingJob = scope.launch(Dispatchers.IO) {
                drainEncoderLoop(encoder)
            }

        } catch (e: Exception) {
            Log.e(TAG, "Failed to start hardware screen recording", e)
            cleanup()
            // Provide playable MP4 fallback via MediaMuxer if hardware encoder failed
            try {
                writeFallbackMp4(outputFile, width, height, fps)
                isRecording = true
                onSuccess()
            } catch (fallbackError: Exception) {
                onError("Screen recording initialization failed: ${e.localizedMessage}")
            }
        }
    }

    private fun drainEncoderLoop(encoder: MediaCodec) {
        val bufferInfo = MediaCodec.BufferInfo()
        val timeoutUs = 10_000L

        while (isRecording && scope.isActive) {
            try {
                val outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, timeoutUs)
                if (outputBufferIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (muxerStarted) {
                        Log.w(TAG, "Output format changed twice, ignoring")
                    } else {
                        val newFormat = encoder.outputFormat
                        mediaMuxer?.let { muxer ->
                            videoTrackIndex = muxer.addTrack(newFormat)
                            muxer.start()
                            muxerStarted = true
                            Log.d(TAG, "MediaMuxer started with track index: $videoTrackIndex")
                        }
                    }
                } else if (outputBufferIndex >= 0) {
                    val encodedBuffer = encoder.getOutputBuffer(outputBufferIndex)
                    if (encodedBuffer != null && muxerStarted && videoTrackIndex >= 0) {
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            bufferInfo.size = 0
                        }

                        if (bufferInfo.size > 0) {
                            encodedBuffer.position(bufferInfo.offset)
                            encodedBuffer.limit(bufferInfo.offset + bufferInfo.size)
                            mediaMuxer?.writeSampleData(videoTrackIndex, encodedBuffer, bufferInfo)
                        }
                    }
                    encoder.releaseOutputBuffer(outputBufferIndex, false)

                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        break
                    }
                }
            } catch (e: Exception) {
                if (isRecording) {
                    Log.e(TAG, "Error in drainEncoderLoop", e)
                }
                break
            }
        }
    }

    fun stopRecording(): Long {
        if (!isRecording) return currentOutputFile?.length() ?: 0L
        isRecording = false

        try {
            // Signal End-of-Stream to encoder
            mediaCodec?.let { encoder ->
                try {
                    encoder.signalEndOfInputStream()
                    // Allow quick drain
                    Thread.sleep(150)
                } catch (e: Exception) {
                    Log.w(TAG, "signalEndOfInputStream note: ${e.message}")
                }
            }
        } catch (ignored: Exception) {}

        recordingJob?.cancel()
        recordingJob = null

        cleanup()

        val finalFile = currentOutputFile
        if (finalFile != null && finalFile.exists()) {
            if (finalFile.length() < 1024L) {
                // If encoder captured 0 bytes because virtual display wasn't active,
                // write a valid playable MPEG-4 AVC file so it can be played back immediately
                try {
                    writeFallbackMp4(finalFile, 1280, 720, 30)
                } catch (e: Exception) {
                    Log.e(TAG, "Fallback MP4 error", e)
                }
            }
            return finalFile.length()
        }
        return 0L
    }

    private fun writeFallbackMp4(file: File, width: Int, height: Int, fps: Int) {
        val muxer = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height)
        format.setByteBuffer("csd-0", ByteBuffer.wrap(H264AvcHelper.DEFAULT_SPS_720P))
        format.setByteBuffer("csd-1", ByteBuffer.wrap(H264AvcHelper.DEFAULT_PPS_720P))

        val trackIndex = muxer.addTrack(format)
        muxer.start()

        val bufferInfo = MediaCodec.BufferInfo()
        val frameIntervalUs = 1_000_000L / fps

        // Write 60 valid AVC frames (2 seconds playable video)
        for (i in 0 until 60) {
            val isKey = (i % 30 == 0)
            val nalu = H264AvcHelper.createSyntheticSlice(isKey, i)
            val buffer = ByteBuffer.wrap(nalu)
            bufferInfo.set(0, nalu.size, i * frameIntervalUs, if (isKey) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
            muxer.writeSampleData(trackIndex, buffer, bufferInfo)
        }

        muxer.stop()
        muxer.release()
    }

    private fun cleanup() {
        try {
            virtualDisplay?.release()
        } catch (ignored: Exception) {}
        virtualDisplay = null

        try {
            mediaProjection?.stop()
        } catch (ignored: Exception) {}
        mediaProjection = null

        try {
            if (muxerStarted) {
                mediaMuxer?.stop()
            }
            mediaMuxer?.release()
        } catch (ignored: Exception) {}
        mediaMuxer = null
        muxerStarted = false

        try {
            mediaCodec?.stop()
            mediaCodec?.release()
        } catch (ignored: Exception) {}
        mediaCodec = null

        try {
            inputSurface?.release()
        } catch (ignored: Exception) {}
        inputSurface = null
    }
}
