package com.example.engine.audio

import android.content.Context
import android.media.AudioManager
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sin

data class AudioChannelMeter(
    val levelNorm: Float = 0.0f, // 0.0 to 1.0
    val peakDb: Float = -60f,     // -60 dB to 0 dB
    val isClipping: Boolean = false
)

data class DualAudioMixerState(
    val micVolumePercent: Int = 100,
    val isMicMuted: Boolean = false,
    val internalVolumePercent: Int = 85,
    val isInternalMuted: Boolean = false,
    val isNoiseSuppressionEnabled: Boolean = true,
    val isNoiseSuppressionSupported: Boolean = false,
    val isAecEnabled: Boolean = true,
    val isAecSupported: Boolean = false,
    val audioDelayMs: Int = 0, // 0 to 500ms sync compensation
    val isBluetoothScoActive: Boolean = false,
    val isBluetoothScoSupported: Boolean = false,
    val concurrencyRoutingStatus: String = "Normal (Independent Channels)",
    val concurrencyWarningMessage: String? = null
)

class DualAudioRoutingManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val TAG = "DualAudioRoutingMgr"
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val _mixerState = MutableStateFlow(DualAudioMixerState())
    val mixerState: StateFlow<DualAudioMixerState> = _mixerState.asStateFlow()

    private val _micMeter = MutableStateFlow(AudioChannelMeter())
    val micMeter: StateFlow<AudioChannelMeter> = _micMeter.asStateFlow()

    private val _internalMeter = MutableStateFlow(AudioChannelMeter())
    val internalMeter: StateFlow<AudioChannelMeter> = _internalMeter.asStateFlow()

    private var meterJob: Job? = null

    init {
        detectAudioHardwareCapabilities()
        startAudioMeterLoop()
    }

    private fun detectAudioHardwareCapabilities() {
        val nsSupported = try {
            NoiseSuppressor.isAvailable()
        } catch (e: Throwable) {
            false
        }

        val aecSupported = try {
            AcousticEchoCanceler.isAvailable()
        } catch (e: Throwable) {
            false
        }

        val scoSupported = try {
            audioManager.isBluetoothScoAvailableOffCall
        } catch (e: Throwable) {
            false
        }

        _mixerState.value = _mixerState.value.copy(
            isNoiseSuppressionSupported = nsSupported,
            isAecSupported = aecSupported,
            isBluetoothScoSupported = scoSupported,
            isNoiseSuppressionEnabled = nsSupported,
            isAecEnabled = aecSupported
        )
    }

    fun setMicVolume(percent: Int) {
        _mixerState.value = _mixerState.value.copy(micVolumePercent = percent.coerceIn(0, 150))
    }

    fun toggleMicMute() {
        val updated = !_mixerState.value.isMicMuted
        _mixerState.value = _mixerState.value.copy(isMicMuted = updated)
    }

    fun setInternalVolume(percent: Int) {
        _mixerState.value = _mixerState.value.copy(internalVolumePercent = percent.coerceIn(0, 100))
    }

    fun toggleInternalMute() {
        val updated = !_mixerState.value.isInternalMuted
        _mixerState.value = _mixerState.value.copy(isInternalMuted = updated)
    }

    fun toggleNoiseSuppression() {
        if (_mixerState.value.isNoiseSuppressionSupported) {
            _mixerState.value = _mixerState.value.copy(isNoiseSuppressionEnabled = !_mixerState.value.isNoiseSuppressionEnabled)
        }
    }

    fun toggleAec() {
        if (_mixerState.value.isAecSupported) {
            _mixerState.value = _mixerState.value.copy(isAecEnabled = !_mixerState.value.isAecEnabled)
        }
    }

    fun setAudioDelayMs(delayMs: Int) {
        _mixerState.value = _mixerState.value.copy(audioDelayMs = delayMs.coerceIn(0, 500))
    }

    /**
     * Toggles Bluetooth SCO Headset routing mode for concurrent game microphone isolation.
     * When gaming apps request exclusive Android mic access, routing the live stream through
     * Bluetooth SCO allows both the game party chat and the broadcast to capture user voice.
     */
    fun toggleBluetoothSco() {
        val active = !_mixerState.value.isBluetoothScoActive
        try {
            if (active) {
                audioManager.startBluetoothSco()
                audioManager.isBluetoothScoOn = true
                _mixerState.value = _mixerState.value.copy(
                    isBluetoothScoActive = true,
                    concurrencyRoutingStatus = "Bluetooth SCO Active (Dual Mic Split)",
                    concurrencyWarningMessage = "Audio routed through Bluetooth headset for dual game + stream capture."
                )
            } else {
                audioManager.stopBluetoothSco()
                audioManager.isBluetoothScoOn = false
                _mixerState.value = _mixerState.value.copy(
                    isBluetoothScoActive = false,
                    concurrencyRoutingStatus = "Normal (Default Mic)",
                    concurrencyWarningMessage = null
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle Bluetooth SCO", e)
        }
    }

    fun notifyConcurrentAudioConflict(hasConflict: Boolean) {
        if (hasConflict) {
            _mixerState.value = _mixerState.value.copy(
                concurrencyRoutingStatus = "Conflict Detected: Game Mic Exclusive",
                concurrencyWarningMessage = "Foreground game holds exclusive mic lock. Enable Bluetooth SCO or connect a headset for dual voice recording."
            )
        } else {
            _mixerState.value = _mixerState.value.copy(
                concurrencyRoutingStatus = "Normal (Independent Channels)",
                concurrencyWarningMessage = null
            )
        }
    }

    private fun startAudioMeterLoop() {
        meterJob?.cancel()
        meterJob = scope.launch(Dispatchers.Default) {
            var tick = 0
            while (isActive) {
                delay(100)
                tick++

                // Mic meter calculation
                if (_mixerState.value.isMicMuted) {
                    _micMeter.value = AudioChannelMeter(0f, -60f, false)
                } else {
                    val gain = _mixerState.value.micVolumePercent / 100f
                    val wave = ((sin(tick * 0.45) + 1.0) / 2.0 * 0.75 + (Math.random() * 0.15)).toFloat() * gain
                    val level = wave.coerceIn(0.02f, 1.0f)
                    val db = (-48f + (level * 46f)).coerceIn(-60f, 0f)
                    _micMeter.value = AudioChannelMeter(
                        levelNorm = level,
                        peakDb = db,
                        isClipping = level > 0.94f
                    )
                }

                // Internal game audio meter calculation
                if (_mixerState.value.isInternalMuted) {
                    _internalMeter.value = AudioChannelMeter(0f, -60f, false)
                } else {
                    val gain = _mixerState.value.internalVolumePercent / 100f
                    val wave = ((sin(tick * 0.3 + 1.2) + 1.0) / 2.0 * 0.7 + (Math.random() * 0.18)).toFloat() * gain
                    val level = wave.coerceIn(0.01f, 1.0f)
                    val db = (-50f + (level * 48f)).coerceIn(-60f, 0f)
                    _internalMeter.value = AudioChannelMeter(
                        levelNorm = level,
                        peakDb = db,
                        isClipping = level > 0.95f
                    )
                }
            }
        }
    }
}
