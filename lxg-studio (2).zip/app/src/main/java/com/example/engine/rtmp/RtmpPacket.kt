package com.example.engine.rtmp

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream

data class RtmpIncomingMessage(
    val csid: Int,
    val typeId: Int,
    val streamId: Int,
    val timestamp: Long,
    val payload: ByteArray
)

object RtmpPacket {

    /**
     * Writes an RTMP message chunked according to standard RTMP chunk stream rules.
     */
    fun writeMessage(
        out: OutputStream,
        csid: Int,
        typeId: Int,
        streamId: Int,
        timestamp: Long,
        payload: ByteArray,
        chunkSize: Int = 4096
    ) {
        val totalLen = payload.size
        var offset = 0
        var isFirstChunk = true

        while (offset < totalLen) {
            val bytesInChunk = (totalLen - offset).coerceAtMost(chunkSize)

            if (isFirstChunk) {
                // fmt 0: 11-byte header
                out.write((0 shl 6) or (csid and 0x3F))

                val ts = if (timestamp >= 0xFFFFFFL) 0xFFFFFFL else timestamp
                out.write(((ts shr 16) and 0xFF).toInt())
                out.write(((ts shr 8) and 0xFF).toInt())
                out.write((ts and 0xFF).toInt())

                out.write(((totalLen shr 16) and 0xFF))
                out.write(((totalLen shr 8) and 0xFF))
                out.write((totalLen and 0xFF))

                out.write(typeId and 0xFF)

                // Message Stream ID is LITTLE ENDIAN in RTMP format 0
                out.write(streamId and 0xFF)
                out.write((streamId shr 8) and 0xFF)
                out.write((streamId shr 16) and 0xFF)
                out.write((streamId shr 24) and 0xFF)

                if (timestamp >= 0xFFFFFFL) {
                    out.write(((timestamp shr 24) and 0xFF).toInt())
                    out.write(((timestamp shr 16) and 0xFF).toInt())
                    out.write(((timestamp shr 8) and 0xFF).toInt())
                    out.write((timestamp and 0xFF).toInt())
                }

                isFirstChunk = false
            } else {
                // fmt 3: 0-byte header
                out.write((3 shl 6) or (csid and 0x3F))
                if (timestamp >= 0xFFFFFFL) {
                    out.write(((timestamp shr 24) and 0xFF).toInt())
                    out.write(((timestamp shr 16) and 0xFF).toInt())
                    out.write(((timestamp shr 8) and 0xFF).toInt())
                    out.write((timestamp and 0xFF).toInt())
                }
            }

            out.write(payload, offset, bytesInChunk)
            offset += bytesInChunk
        }
        out.flush()
    }

    /**
     * Reads a complete RTMP packet from the input stream.
     */
    fun readMessage(input: InputStream, currentChunkSize: Int = 128): RtmpIncomingMessage? {
        val b0 = input.read()
        if (b0 == -1) return null
        val fmt = (b0 shr 6) and 0x03
        var csid = b0 and 0x3F
        if (csid == 0) {
            val b1 = input.read()
            if (b1 == -1) return null
            csid = 64 + b1
        } else if (csid == 1) {
            val b1 = input.read()
            val b2 = input.read()
            if (b1 == -1 || b2 == -1) return null
            csid = 64 + b1 + (b2 shl 8)
        }

        var timestamp = 0L
        var length = 0
        var typeId = 0
        var streamId = 0

        when (fmt) {
            0 -> {
                // 11 bytes header
                timestamp = ((input.read() shl 16) or (input.read() shl 8) or input.read()).toLong()
                length = (input.read() shl 16) or (input.read() shl 8) or input.read()
                typeId = input.read()
                streamId = input.read() or (input.read() shl 8) or (input.read() shl 16) or (input.read() shl 24)
            }
            1 -> {
                // 7 bytes header
                timestamp = ((input.read() shl 16) or (input.read() shl 8) or input.read()).toLong()
                length = (input.read() shl 16) or (input.read() shl 8) or input.read()
                typeId = input.read()
            }
            2 -> {
                // 3 bytes header
                timestamp = ((input.read() shl 16) or (input.read() shl 8) or input.read()).toLong()
            }
            3 -> {
                // 0 bytes header
            }
        }

        if (timestamp == 0xFFFFFFL) {
            timestamp = ((input.read().toLong() shl 24) or
                    (input.read().toLong() shl 16) or
                    (input.read().toLong() shl 8) or
                    input.read().toLong())
        }

        if (length <= 0) {
            return RtmpIncomingMessage(csid, typeId, streamId, timestamp, ByteArray(0))
        }

        val payload = ByteArray(length)
        var readTotal = 0
        while (readTotal < length) {
            val toRead = (length - readTotal).coerceAtMost(currentChunkSize)
            var chunkRead = 0
            while (chunkRead < toRead) {
                val r = input.read(payload, readTotal + chunkRead, toRead - chunkRead)
                if (r == -1) return null
                chunkRead += r
            }
            readTotal += chunkRead

            // If there's more chunks to read for this packet, skip the fmt 3 delimiter
            if (readTotal < length) {
                val skipDelimiter = input.read()
                if (skipDelimiter == -1) return null
            }
        }

        return RtmpIncomingMessage(csid, typeId, streamId, timestamp, payload)
    }
}
