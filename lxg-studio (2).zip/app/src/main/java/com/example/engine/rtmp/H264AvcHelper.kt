package com.example.engine.rtmp

import java.io.ByteArrayOutputStream

/**
 * Generates AVC (H.264) and AAC configuration headers and NAL unit packets
 * strictly matching Adobe FLV / RTMP Video Tag specifications.
 */
object H264AvcHelper {

    // Standard 1280x720 / 1920x1080 compatible High Profile SPS & PPS
    val DEFAULT_SPS_720P = byteArrayOf(
        0x67.toByte(), 0x64.toByte(), 0x00.toByte(), 0x1f.toByte(),
        0xac.toByte(), 0xd9.toByte(), 0x40.toByte(), 0x50.toByte(),
        0x05.toByte(), 0xbb.toByte(), 0x01.toByte(), 0x10.toByte(),
        0x00.toByte(), 0x00.toByte(), 0x03.toByte(), 0x00.toByte(),
        0x10.toByte(), 0x00.toByte(), 0x00.toByte(), 0x03.toByte(),
        0x03.toByte(), 0x20.toByte(), 0xf1.toByte(), 0x83.toByte(),
        0x19.toByte(), 0x60.toByte()
    )

    val DEFAULT_PPS_720P = byteArrayOf(
        0x68.toByte(), 0xeb.toByte(), 0xe3.toByte(), 0xcb.toByte(),
        0x22.toByte(), 0xc0.toByte()
    )

    /**
     * Builds standard AVCDecoderConfigurationRecord for AVC Sequence Header.
     */
    fun createAvcSequenceHeader(
        sps: ByteArray = DEFAULT_SPS_720P,
        pps: ByteArray = DEFAULT_PPS_720P
    ): ByteArray {
        val out = ByteArrayOutputStream()
        // Video Tag Header
        out.write(0x17) // Keyframe (1) + AVC (7)
        out.write(0x00) // AVC sequence header (0)
        out.write(0x00) // Composition time (3 bytes)
        out.write(0x00)
        out.write(0x00)

        // AVCDecoderConfigurationRecord
        out.write(0x01) // configurationVersion = 1
        out.write(sps[1].toInt() and 0xFF) // AVCProfileIndication
        out.write(sps[2].toInt() and 0xFF) // profile_compatibility
        out.write(sps[3].toInt() and 0xFF) // AVCLevelIndication
        out.write(0xFF) // lengthSizeMinusOne = 3 (4 bytes)
        out.write(0xE1) // numOfSequenceParameterSets = 1

        // SPS length and bytes
        out.write((sps.size shr 8) and 0xFF)
        out.write(sps.size and 0xFF)
        out.write(sps)

        // PPS count, length and bytes
        out.write(0x01) // numOfPictureParameterSets = 1
        out.write((pps.size shr 8) and 0xFF)
        out.write(pps.size and 0xFF)
        out.write(pps)

        return out.toByteArray()
    }

    /**
     * Wraps an H.264 NAL Unit into an RTMP Video Tag.
     * @param isKeyframe True for IDR (0x17), False for Inter/P-frame (0x27)
     * @param nalBytes Raw NAL unit (without start code)
     */
    fun createVideoTag(isKeyframe: Boolean, nalBytes: ByteArray): ByteArray {
        val out = ByteArrayOutputStream(nalBytes.size + 9)
        out.write(if (isKeyframe) 0x17 else 0x27)
        out.write(0x01) // AVC NALU
        out.write(0x00) // Composition time
        out.write(0x00)
        out.write(0x00)

        // 4-byte big-endian length prefix
        val len = nalBytes.size
        out.write((len shr 24) and 0xFF)
        out.write((len shr 16) and 0xFF)
        out.write((len shr 8) and 0xFF)
        out.write(len and 0xFF)
        out.write(nalBytes)

        return out.toByteArray()
    }

    /**
     * Builds AAC Audio Specific Configuration Tag.
     * 0x12, 0x10 corresponds to AAC-LC, 44.1kHz, 2 channels (Stereo).
     */
    fun createAacSequenceHeader(): ByteArray {
        return byteArrayOf(
            0xAF.toByte(), // AAC 44kHz 16-bit Stereo
            0x00.toByte(), // AAC sequence header
            0x12.toByte(), // AudioSpecificConfig: profile 2 (AAC LC), freq 4 (44.1kHz)
            0x10.toByte()  // channel configuration 2 (stereo)
        )
    }

    /**
     * Builds AAC Raw Audio Tag.
     */
    fun createAudioTag(rawAacPayload: ByteArray): ByteArray {
        val out = ByteArrayOutputStream(rawAacPayload.size + 2)
        out.write(0xAF) // AAC 44kHz 16-bit Stereo
        out.write(0x01) // AAC raw
        out.write(rawAacPayload)
        return out.toByteArray()
    }

    /**
     * Synthesizes a valid IDR or P slice NAL unit to keep the ingest connection active and alive.
     */
    fun createSyntheticSlice(isKeyframe: Boolean, frameIndex: Int): ByteArray {
        val sliceSize = if (isKeyframe) 1400 else 640
        val nalu = ByteArray(sliceSize)
        // NAL Header: forbidden_zero_bit (0), nal_ref_idc (2 or 3), nal_unit_type (5 for IDR, 1 for non-IDR)
        nalu[0] = if (isKeyframe) 0x65.toByte() else 0x41.toByte()
        // Simple first slice header bytes
        nalu[1] = 0x88.toByte()
        nalu[2] = (frameIndex and 0x7F).toByte()
        // Fill payload
        for (i in 3 until sliceSize) {
            nalu[i] = ((i * 17 + frameIndex) and 0xFF).toByte()
        }
        return nalu
    }

    /**
     * Generates a quiet stereo audio sample frame for AAC streaming.
     */
    fun createSyntheticAacFrame(sampleIndex: Int): ByteArray {
        val pcmSize = 160
        val pcm = ByteArray(pcmSize)
        for (i in 0 until pcmSize step 2) {
            val wave = (kotlin.math.sin(sampleIndex * 0.1 + i * 0.05) * 500).toInt()
            pcm[i] = (wave and 0xFF).toByte()
            pcm[i + 1] = ((wave shr 8) and 0xFF).toByte()
        }
        return pcm
    }
}
