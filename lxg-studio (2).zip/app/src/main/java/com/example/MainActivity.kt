package com.example

import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.example.ui.MainViewModel
import com.example.ui.NavigationTab
import com.example.ui.components.LXGBottomNavigationBar
import com.example.ui.components.StudioTopBar
import com.example.ui.dashboard.DashboardScreen
import com.example.ui.destinations.DestinationsScreen
import com.example.ui.recordings.RecordingsScreen
import com.example.ui.recordings.VideoPlaybackDialog
import com.example.ui.settings.SettingsScreen
import com.example.ui.studio.StudioScreen
import com.example.ui.theme.LXGStudioTheme
import com.example.ui.theme.StudioDarkBg

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LXGStudioTheme {
                LXGStudioApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun LXGStudioApp(viewModel: MainViewModel) {
    val context = LocalContext.current
    val currentTab by viewModel.currentTab.collectAsState()
    val streamStatus by viewModel.streamStatus.collectAsState()
    val recordingStatus by viewModel.recordingStatus.collectAsState()
    val telemetry by viewModel.telemetry.collectAsState()
    val activePlayback by viewModel.activePlaybackRecording.collectAsState()

    // Request permissions proactively on first launch
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { /* handled */ }

    LaunchedEffect(Unit) {
        val permissions = mutableListOf(
            android.Manifest.permission.CAMERA,
            android.Manifest.permission.RECORD_AUDIO
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        val needed = permissions.filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    // BackHandler: Return to Home tab if on sub-screens
    BackHandler(enabled = currentTab != NavigationTab.HOME) {
        viewModel.selectTab(NavigationTab.HOME)
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioDarkBg),
        topBar = {
            StudioTopBar(
                streamStatus = streamStatus,
                recordingStatus = recordingStatus,
                telemetry = telemetry
            )
        },
        bottomBar = {
            LXGBottomNavigationBar(
                currentTab = currentTab,
                onTabSelected = { viewModel.selectTab(it) }
            )
        },
        containerColor = StudioDarkBg
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(targetState = currentTab, label = "tab_crossfade") { tab ->
                when (tab) {
                    NavigationTab.HOME -> DashboardScreen(
                        viewModel = viewModel,
                        onNavigateTab = { viewModel.selectTab(it) }
                    )
                    NavigationTab.STUDIO -> StudioScreen(viewModel = viewModel)
                    NavigationTab.DESTINATIONS -> DestinationsScreen(viewModel = viewModel)
                    NavigationTab.RECORDINGS -> RecordingsScreen(viewModel = viewModel)
                    NavigationTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
                }
            }
        }
    }

    // Global Video Playback Modal Player
    activePlayback?.let { rec ->
        VideoPlaybackDialog(
            recording = rec,
            onDismiss = { viewModel.closePlayback() }
        )
    }
}
