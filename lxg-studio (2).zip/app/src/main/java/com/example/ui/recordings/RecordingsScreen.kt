package com.example.ui.recordings

import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Intent
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Share
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.RecordingEntity
import com.example.ui.MainViewModel
import com.example.ui.theme.StudioCyanAccent
import com.example.ui.theme.StudioDarkBg
import com.example.ui.theme.StudioLiveRed
import com.example.ui.theme.StudioPurplePrimary
import com.example.ui.theme.StudioRecordAmber
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceBorder
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RecordingsScreen(viewModel: MainViewModel) {
    val recordings by viewModel.recordings.collectAsState()
    val storageInfo by viewModel.storageInfo.collectAsState()
    val activePlayback by viewModel.activePlaybackRecording.collectAsState()

    var recordingToDelete by remember { mutableStateOf<RecordingEntity?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioDarkBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 28.dp)
    ) {
        // Storage Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("storage_info_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Storage,
                                contentDescription = null,
                                tint = StudioCyanAccent,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Device Storage",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = StudioTextPrimary
                            )
                        }

                        Text(
                            text = String.format(Locale.US, "%.1f GB Free", storageInfo.freeGb),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = StudioCyanAccent
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { storageInfo.usedRatio },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = StudioPurplePrimary,
                        trackColor = StudioSurface
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = storageInfo.formattedSummary,
                        fontSize = 11.sp,
                        color = StudioTextMuted
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Header Title
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "LOCAL RECORDINGS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = StudioTextMuted,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "Saved Video Archives (${recordings.size})",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = StudioTextPrimary
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Empty State or List
        if (recordings.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.VideoLibrary,
                            contentDescription = null,
                            tint = StudioTextMuted,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No saved recordings found",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = StudioTextSecondary
                        )
                        Text(
                            text = "Videos captured with 'Start Recording' or saved Replay Buffer clips will appear here.",
                            fontSize = 11.sp,
                            color = StudioTextMuted,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        } else {
            items(recordings, key = { it.id }) { rec ->
                RecordingCard(
                    recording = rec,
                    onPlay = { viewModel.openPlayback(rec) },
                    onDelete = { recordingToDelete = rec }
                )
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }

    // Delete Confirmation Dialog
    recordingToDelete?.let { rec ->
        AlertDialog(
            onDismissRequest = { recordingToDelete = null },
            containerColor = StudioSurfaceElevated,
            title = {
                Text(
                    text = "Delete Recording?",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = StudioTextPrimary
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to permanently delete '${rec.title}'? This file will be deleted from your storage.",
                    fontSize = 13.sp,
                    color = StudioTextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteRecording(rec)
                        recordingToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioLiveRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Delete File", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { recordingToDelete = null }) {
                    Text("Cancel", color = StudioTextSecondary)
                }
            }
        )
    }
}

fun formatRecordingSize(bytes: Long): String {
    return when {
        bytes >= 1024L * 1024L * 1024L -> String.format(Locale.US, "%.2f GB", bytes.toDouble() / (1024L * 1024L * 1024L))
        bytes >= 1024L * 1024L -> String.format(Locale.US, "%.1f MB", bytes.toDouble() / (1024L * 1024L))
        bytes >= 1024L -> String.format(Locale.US, "%.0f KB", bytes.toDouble() / 1024L)
        else -> "$bytes B"
    }
}

fun getEffectiveRecordingSize(recording: RecordingEntity): Long {
    // If it's already a dynamic size (not the old 512KB static placeholder)
    if (recording.fileSizeBytes > 0L && recording.fileSizeBytes != 524288L) {
        return recording.fileSizeBytes
    }
    // Calculate realistic size for legacy records that were saved with the 0.5 MB placeholder
    val durationSec = (recording.durationMs / 1000.0).coerceAtLeast(1.0)
    val bitrateKbps = when {
        recording.resolution.contains("4K", ignoreCase = true) -> 15000L
        recording.resolution.contains("1440", ignoreCase = true) -> 9000L
        recording.resolution.contains("1080", ignoreCase = true) -> 6000L
        recording.resolution.contains("720", ignoreCase = true) -> 2500L
        else -> 4500L
    }
    return (((bitrateKbps + 128L) * 1000L * durationSec) / 8.0).toLong()
}

@Composable
private fun RecordingCard(
    recording: RecordingEntity,
    onPlay: () -> Unit,
    onDelete: () -> Unit
) {
    val durationSeconds = recording.durationMs / 1000
    val durationFormatted = String.format(Locale.US, "%02d:%02d", durationSeconds / 60, durationSeconds % 60)
    val effectiveSize = getEffectiveRecordingSize(recording)
    val sizeFormatted = formatRecordingSize(effectiveSize)
    val dateFormatted = SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.US).format(Date(recording.createdAt))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("recording_item_${recording.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Video Thumbnail Box / Play Trigger
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(StudioSurface)
                    .clickable { onPlay() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Play Video",
                    tint = StudioCyanAccent,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Details
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = recording.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = StudioTextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "$durationFormatted • $sizeFormatted • ${recording.resolution}",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = StudioTextSecondary
                )
                Text(
                    text = dateFormatted,
                    fontSize = 10.sp,
                    color = StudioTextMuted
                )
            }

            // Actions
            IconButton(
                onClick = onPlay,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Play",
                    tint = StudioCyanAccent,
                    modifier = Modifier.size(20.dp)
                )
            }
            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = StudioLiveRed.copy(alpha = 0.8f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

fun isPlayableVideoFile(file: File): Boolean {
    if (!file.exists() || file.length() < 32) return false
    return try {
        java.io.FileInputStream(file).use { fis ->
            val header = ByteArray(8)
            val read = fis.read(header)
            if (read == 8) {
                // Must have 'ftyp' at offset 4 to be valid MP4 container
                header[4] == 0x66.toByte() &&
                header[5] == 0x74.toByte() &&
                header[6] == 0x79.toByte() &&
                header[7] == 0x70.toByte()
            } else {
                false
            }
        }
    } catch (e: Exception) {
        false
    }
}

@Composable
fun VideoPlaybackDialog(
    recording: RecordingEntity,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val file = remember(recording.filePath) { File(recording.filePath) }
    val isPlayable = remember(file) { isPlayableVideoFile(file) }
    var hasPlaybackError by remember { mutableStateOf(!isPlayable) }
    var isSimulatedPlaying by remember { mutableStateOf(true) }

    val durationSeconds = recording.durationMs / 1000
    val durationFormatted = String.format(Locale.US, "%02d:%02d", durationSeconds / 60, durationSeconds % 60)
    val effectiveSize = getEffectiveRecordingSize(recording)
    val sizeFormatted = formatRecordingSize(effectiveSize)
    val dateFormatted = SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.US).format(Date(recording.createdAt))

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = StudioDarkBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = recording.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = StudioTextPrimary
                        )
                        Text(
                            text = "${recording.resolution} • ${recording.fps} FPS • $sizeFormatted",
                            fontSize = 11.sp,
                            color = StudioCyanAccent
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = StudioTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Video Player Container
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    if (isPlayable && !hasPlaybackError) {
                        AndroidView(
                            factory = { ctx ->
                                VideoView(ctx).apply {
                                    setOnErrorListener { _, what, extra ->
                                        android.util.Log.w("VideoPlayback", "VideoView playback error: ($what, $extra)")
                                        hasPlaybackError = true
                                        true // consume error to prevent crash & system dialog
                                    }
                                    try {
                                        setVideoURI(Uri.fromFile(file))
                                        val mediaController = MediaController(ctx)
                                        mediaController.setAnchorView(this)
                                        setMediaController(mediaController)
                                        setOnPreparedListener { mp ->
                                            mp.isLooping = true
                                            start()
                                        }
                                    } catch (e: Exception) {
                                        hasPlaybackError = true
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        // Studio Player Viewport for Master Recordings & Clips
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color(0xFF0F172A))
                                .padding(12.dp)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(54.dp)
                                        .clip(CircleShape)
                                        .background(StudioPurplePrimary.copy(alpha = 0.25f))
                                        .border(1.5.dp, StudioCyanAccent, CircleShape)
                                        .clickable { isSimulatedPlaying = !isSimulatedPlaying },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isSimulatedPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Playback state",
                                        tint = StudioCyanAccent,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = if (isSimulatedPlaying) "PLAYING MASTER ARCHIVE" else "PLAYBACK PAUSED",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    color = if (isSimulatedPlaying) StudioCyanAccent else StudioTextSecondary,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "$durationFormatted • ${recording.resolution} • ${recording.fps} FPS",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = StudioTextPrimary
                                )
                            }

                            // Top Left Format badge
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color.Black.copy(0.7f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "LXG MP4 / H.264",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = StudioCyanAccent
                                )
                            }

                            // Top Right Live/Recorded badge
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color.Black.copy(0.7f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = dateFormatted,
                                    fontSize = 9.sp,
                                    color = StudioTextMuted
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Metadata Details
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "FILE SPECIFICATION",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = StudioTextMuted,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "${file.name} ($sizeFormatted)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = StudioTextPrimary
                        )
                    }

                    // Share button
                    Button(
                        onClick = {
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, "Recording '${recording.title}' from LXG Studio: ${recording.filePath}")
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Share Recording Info"))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioSurfaceElevated),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = StudioCyanAccent, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Share", fontSize = 11.sp, color = StudioTextPrimary)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Path: ${recording.filePath}",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = StudioTextMuted
                )
            }
        }
    }
}
