package com.example.data.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.security.KeyStoreEncryptionHelper

/**
 * Encrypted payload holder for RTMP stream credentials.
 */
data class EncryptedStreamKey(
    val cipherTextBase64: String,
    val ivBase64: String,
    val maskedKey: String,
    val algorithm: String = "AES/GCM/NoPadding"
)

/**
 * Domain Data Class representing an RTMP / RTMPS streaming destination.
 *
 * This data class is used in UI, view models, and stream engine components.
 * It contains utility functions for URL validation, automatic AES-256-GCM
 * encryption for storage, and safe key masking to prevent leaking secrets.
 */
data class RtmpDestination(
    val id: Long = 0,
    val platformName: String = "Custom RTMP", // "YouTube Live", "Twitch", "Facebook Live", "Custom RTMP", "Custom RTMPS"
    val label: String = "",
    val serverUrl: String,
    val streamKey: String = "",
    val isEnabled: Boolean = true,
    val lastPingMs: Long = -1,
    val createdAt: Long = System.currentTimeMillis()
) {
    /**
     * Returns true if the server URL uses secure RTMPS (TLS/SSL).
     */
    val isRtmps: Boolean
        get() = serverUrl.trim().startsWith("rtmps://", ignoreCase = true)

    /**
     * Returns true if the server URL is a valid RTMP or RTMPS endpoint.
     */
    fun isValidServerUrl(): Boolean {
        val trimmed = serverUrl.trim().lowercase()
        return trimmed.startsWith("rtmp://") || trimmed.startsWith("rtmps://")
    }

    /**
     * Generates a masked preview of the stream key (e.g. "••••••••94a2")
     * so that the full secret is never exposed in UI previews or logs.
     */
    val maskedKey: String
        get() = KeyStoreEncryptionHelper.maskKey(streamKey)

    /**
     * Computes the complete publish URL combining server endpoint and stream key.
     */
    fun getFullPublishUrl(): String {
        val trimmedUrl = serverUrl.trim().trimEnd('/')
        val trimmedKey = streamKey.trim().trimStart('/')
        return if (trimmedKey.isEmpty()) trimmedUrl else "$trimmedUrl/$trimmedKey"
    }

    /**
     * Encrypts the stream key using the Android Hardware Keystore AES-256-GCM cipher
     * and converts this domain model into a persistent Room Entity.
     */
    fun toEntity(): RtmpDestinationEntity {
        val encrypted = KeyStoreEncryptionHelper.encrypt(streamKey)
        val masked = KeyStoreEncryptionHelper.maskKey(streamKey)
        return RtmpDestinationEntity(
            id = id,
            platformName = platformName,
            label = label.ifBlank { platformName },
            serverUrl = serverUrl.trim(),
            encryptedKey = encrypted.cipherTextBase64,
            iv = encrypted.ivBase64,
            maskedKey = masked,
            encryptionAlgorithm = "AES/GCM/NoPadding",
            keyAlias = "LXG_STUDIO_MASTER_KEY",
            isEnabled = isEnabled,
            lastPingMs = lastPingMs,
            createdAt = createdAt
        )
    }

    /**
     * Compatibility helper to convert to existing legacy DestinationEntity if needed.
     */
    fun toLegacyDestinationEntity(): DestinationEntity {
        val encrypted = KeyStoreEncryptionHelper.encrypt(streamKey)
        val masked = KeyStoreEncryptionHelper.maskKey(streamKey)
        return DestinationEntity(
            id = id,
            platformName = platformName,
            label = label.ifBlank { platformName },
            serverUrl = serverUrl.trim(),
            encryptedKey = encrypted.cipherTextBase64,
            iv = encrypted.ivBase64,
            maskedKey = masked,
            isEnabled = isEnabled,
            lastPingMs = lastPingMs,
            createdAt = createdAt
        )
    }
}

/**
 * Room Database Entity to persist RTMP server URLs and securely encrypted stream keys.
 *
 * Stream keys are strictly stored as AES-256-GCM encrypted ciphertexts with their unique
 * Initialization Vector (IV). Plaintext keys are never stored on disk.
 */
@Entity(tableName = "rtmp_destinations")
data class RtmpDestinationEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0,

    @ColumnInfo(name = "platform_name")
    val platformName: String,

    @ColumnInfo(name = "label")
    val label: String,

    @ColumnInfo(name = "server_url")
    val serverUrl: String,

    @ColumnInfo(name = "encrypted_key")
    val encryptedKey: String,

    @ColumnInfo(name = "iv")
    val iv: String,

    @ColumnInfo(name = "masked_key")
    val maskedKey: String,

    @ColumnInfo(name = "encryption_algorithm")
    val encryptionAlgorithm: String = "AES/GCM/NoPadding",

    @ColumnInfo(name = "key_alias")
    val keyAlias: String = "LXG_STUDIO_MASTER_KEY",

    @ColumnInfo(name = "is_enabled")
    val isEnabled: Boolean = true,

    @ColumnInfo(name = "last_ping_ms")
    val lastPingMs: Long = -1,

    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
) {
    /**
     * Decrypts the stream key using the Android Hardware Keystore AES-256-GCM cipher.
     */
    fun decryptStreamKey(): String {
        return KeyStoreEncryptionHelper.decrypt(encryptedKey, iv)
    }

    /**
     * Converts this Room Entity back into the unencrypted domain model [RtmpDestination].
     */
    fun toDomainModel(): RtmpDestination {
        return RtmpDestination(
            id = id,
            platformName = platformName,
            label = label,
            serverUrl = serverUrl,
            streamKey = decryptStreamKey(),
            isEnabled = isEnabled,
            lastPingMs = lastPingMs,
            createdAt = createdAt
        )
    }

    companion object {
        /**
         * Factory method to build and encrypt an [RtmpDestinationEntity] from plain parameters.
         */
        fun createSecure(
            id: Long = 0,
            platformName: String,
            label: String,
            serverUrl: String,
            rawStreamKey: String,
            isEnabled: Boolean = true
        ): RtmpDestinationEntity {
            val encrypted = KeyStoreEncryptionHelper.encrypt(rawStreamKey)
            val masked = KeyStoreEncryptionHelper.maskKey(rawStreamKey)
            return RtmpDestinationEntity(
                id = id,
                platformName = platformName,
                label = label.ifBlank { platformName },
                serverUrl = serverUrl.trim(),
                encryptedKey = encrypted.cipherTextBase64,
                iv = encrypted.ivBase64,
                maskedKey = masked,
                isEnabled = isEnabled
            )
        }
    }
}
