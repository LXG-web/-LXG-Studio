package com.example.data.model.obs

enum class CanvasOrientation(val label: String, val aspectRatio: Float, val defaultWidth: Int, val defaultHeight: Int) {
    HORIZONTAL_16_9("Horizontal 16:9 (Long Feed)", 16f / 9f, 1920, 1080),
    VERTICAL_9_16("Vertical 9:16 (Short Feed)", 9f / 16f, 1080, 1920)
}

enum class CanvasPreset(val label: String, val width: Int, val height: Int, val orientation: CanvasOrientation) {
    FHD_1080P_HORIZONTAL("1080p FHD (1920x1080)", 1920, 1080, CanvasOrientation.HORIZONTAL_16_9),
    HD_720P_HORIZONTAL("720p HD (1280x720)", 1280, 720, CanvasOrientation.HORIZONTAL_16_9),
    QHD_1440P_HORIZONTAL("1440p 2K (2560x1440)", 2560, 1440, CanvasOrientation.HORIZONTAL_16_9),
    UHD_4K_HORIZONTAL("4K UHD (3840x2160)", 3840, 2160, CanvasOrientation.HORIZONTAL_16_9),

    FHD_1080P_VERTICAL("1080p Shorts/Reels (1080x1920)", 1080, 1920, CanvasOrientation.VERTICAL_9_16),
    HD_720P_VERTICAL("720p Shorts/Reels (720x1280)", 720, 1280, CanvasOrientation.VERTICAL_9_16)
}

enum class CanvasScaleMode(val label: String) {
    FIT("Fit to Screen"),
    FILL("Fill Screen (Crop)"),
    STRETCH("Stretch to Fill"),
    CENTER("Center 1:1")
}

enum class CanvasBackgroundType(val label: String) {
    SOLID_DARK("Studio Dark"),
    SOLID_BLACK("Pure Black (OLED)"),
    CYBER_GRADIENT("Cyber Gradient"),
    BLUR_BACKGROUND("Dynamic Backdrop Blur")
}

data class CanvasConfig(
    val orientation: CanvasOrientation = CanvasOrientation.HORIZONTAL_16_9,
    val preset: CanvasPreset = CanvasPreset.FHD_1080P_HORIZONTAL,
    val width: Int = 1920,
    val height: Int = 1080,
    val scaleMode: CanvasScaleMode = CanvasScaleMode.FIT,
    val backgroundType: CanvasBackgroundType = CanvasBackgroundType.SOLID_DARK,
    val showSafeZones: Boolean = true,
    val customColorHex: String = "#0A0E1A"
)

enum class SourceType(val displayName: String, val defaultZIndex: Int) {
    BACKGROUND("Background Layer", 0),
    SCREEN_CAPTURE("Screen Capture Source", 1),
    CAMERA_PIP("Camera PIP (Facecam)", 10),
    IMAGE_LOGO("Image / Logo Watermark", 20),
    TEXT_LABEL("Text / Gamer Tag", 30),
    BROWSER_WIDGET("Browser / Web Widget", 35),
    ALERT_BOX("Stream Alerts Box", 40),
    CHAT_OVERLAY("Live Chat HUD", 50),
    COUNTDOWN_TIMER("Countdown Timer", 60),
    VIEWER_COUNTER("Viewer Counter HUD", 70),
    FRAME_BORDER("Custom Frame / Border", 80)
}

data class ObsSource(
    val id: String,
    val name: String,
    val type: SourceType,
    val isVisible: Boolean = true,
    val isLocked: Boolean = false,
    val zIndex: Int = type.defaultZIndex,
    // Relative coordinates within canvas (0.0f to 1.0f)
    val xPercent: Float = 0.05f,
    val yPercent: Float = 0.05f,
    val widthPercent: Float = 0.35f,
    val heightPercent: Float = 0.25f,
    val opacity: Float = 1.0f,
    // Source-specific configs
    val textContent: String = "",
    val textColorHex: String = "#FFFFFF",
    val backgroundColorHex: String = "#1E293B",
    val shapeType: String = "ROUNDED", // "ROUNDED", "RECTANGLE", "CIRCLE"
    val targetUrl: String = "",
    val timerSecondsRemaining: Int = 300,
    val isFrontCamera: Boolean = true,
    val imageUri: String? = null,
    val fontSizeSp: Int = 14,
    val textAlignment: String = "START" // "START", "CENTER", "END"
)

enum class ScenePresetType(val displayName: String) {
    STARTING_SOON("Starting Soon"),
    GAMEPLAY("Gameplay + Cam"),
    JUST_CHATTING("Just Chatting"),
    BE_RIGHT_BACK("Be Right Back"),
    ENDING_SCREEN("Ending Stream"),
    CUSTOM("Custom Scene")
}

data class ObsScene(
    val id: String,
    val name: String,
    val presetType: ScenePresetType,
    val orientation: CanvasOrientation = CanvasOrientation.HORIZONTAL_16_9,
    val sources: List<ObsSource> = emptyList(),
    val isTransitioning: Boolean = false
)
