package com.example.data.repository

import com.example.data.db.RtmpDestinationDao
import com.example.data.model.RtmpDestination
import com.example.data.model.RtmpDestinationEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Repository abstracting RTMP destination storage, automatic AES-256-GCM encryption
 * when saving to Room, and decryption when consuming endpoints.
 */
class RtmpDestinationRepository(
    private val dao: RtmpDestinationDao
) {
    /**
     * Reactive stream of persistent Room entities.
     */
    val allEntities: Flow<List<RtmpDestinationEntity>> = dao.getAllDestinations()

    /**
     * Reactive stream of decrypted domain models ready for UI and stream engine use.
     */
    val allDestinations: Flow<List<RtmpDestination>> = dao.getAllDestinations().map { list ->
        list.map { it.toDomainModel() }
    }

    /**
     * Reactive stream of only enabled destinations.
     */
    val enabledDestinations: Flow<List<RtmpDestination>> = dao.getEnabledDestinationsFlow().map { list ->
        list.map { it.toDomainModel() }
    }

    /**
     * Saves or updates an RTMP destination, automatically encrypting the raw stream key
     * before persisting to Room.
     */
    suspend fun saveDestination(destination: RtmpDestination): Long {
        val entity = destination.toEntity()
        return if (entity.id == 0L) {
            dao.insert(entity)
        } else {
            dao.update(entity)
            entity.id
        }
    }

    /**
     * Retrieves a destination by ID and returns the decrypted domain model.
     */
    suspend fun getDestinationById(id: Long): RtmpDestination? {
        return dao.getDestinationById(id)?.toDomainModel()
    }

    /**
     * Retrieves the decrypted stream key for a specific destination ID.
     */
    suspend fun getDecryptedStreamKey(id: Long): String? {
        return dao.getDestinationById(id)?.decryptStreamKey()
    }

    /**
     * Toggles the active/enabled status of a destination.
     */
    suspend fun setEnabled(id: Long, isEnabled: Boolean) {
        dao.updateEnabled(id, isEnabled)
    }

    /**
     * Updates server ping latency.
     */
    suspend fun updatePing(id: Long, pingMs: Long) {
        dao.updatePing(id, pingMs)
    }

    /**
     * Deletes a destination.
     */
    suspend fun delete(destination: RtmpDestination) {
        dao.deleteById(destination.id)
    }

    /**
     * Deletes a destination by ID.
     */
    suspend fun deleteById(id: Long) {
        dao.deleteById(id)
    }
}
