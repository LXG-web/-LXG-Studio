package com.example

import android.app.Application
import com.example.data.db.AppDatabase
import com.example.data.model.DestinationEntity
import com.example.data.model.RtmpDestinationEntity
import com.example.data.model.SceneEntity
import com.example.data.repository.RtmpDestinationRepository
import com.example.data.security.KeyStoreEncryptionHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class LXGApplication : Application() {
    companion object {
        lateinit var instance: LXGApplication
            private set
    }

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
    val rtmpDestinationRepository: RtmpDestinationRepository by lazy {
        RtmpDestinationRepository(database.rtmpDestinationDao())
    }
    val streamEngine: com.example.engine.StreamEngine by lazy {
        com.example.engine.StreamEngine(this, applicationScope)
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        seedInitialDataIfEmpty()
    }

    private fun seedInitialDataIfEmpty() {
        applicationScope.launch {
            val destinationDao = database.destinationDao()
            val existing = destinationDao.getEnabledDestinations()
            if (existing.isEmpty()) {
                // Seed YouTube Live
                val ytKey = "live_sample_yt88"
                val ytEncrypted = KeyStoreEncryptionHelper.encrypt(ytKey)
                destinationDao.insert(
                    DestinationEntity(
                        platformName = "YouTube Live",
                        label = "YouTube Main Channel",
                        serverUrl = "rtmp://a.rtmp.youtube.com/live2",
                        encryptedKey = ytEncrypted.cipherTextBase64,
                        iv = ytEncrypted.ivBase64,
                        maskedKey = KeyStoreEncryptionHelper.maskKey(ytKey),
                        isEnabled = true
                    )
                )

                // Seed Twitch
                val twitchKey = "live_sample_tw77"
                val twitchEncrypted = KeyStoreEncryptionHelper.encrypt(twitchKey)
                destinationDao.insert(
                    DestinationEntity(
                        platformName = "Twitch",
                        label = "Twitch Gaming Hub",
                        serverUrl = "rtmp://live.twitch.tv/app/",
                        encryptedKey = twitchEncrypted.cipherTextBase64,
                        iv = twitchEncrypted.ivBase64,
                        maskedKey = KeyStoreEncryptionHelper.maskKey(twitchKey),
                        isEnabled = false
                    )
                )

                // Seed Facebook Live
                val fbKey = "live_sample_fb66"
                val fbEncrypted = KeyStoreEncryptionHelper.encrypt(fbKey)
                destinationDao.insert(
                    DestinationEntity(
                        platformName = "Facebook Live",
                        label = "Facebook Creator Page",
                        serverUrl = "rtmps://live-api-s.facebook.com:443/rtmp/",
                        encryptedKey = fbEncrypted.cipherTextBase64,
                        iv = fbEncrypted.ivBase64,
                        maskedKey = KeyStoreEncryptionHelper.maskKey(fbKey),
                        isEnabled = false
                    )
                )
            }

            // Seed rtmp_destinations table if empty
            val rtmpDao = database.rtmpDestinationDao()
            if (rtmpDao.getEnabledDestinations().isEmpty()) {
                rtmpDao.insert(
                    RtmpDestinationEntity.createSecure(
                        platformName = "YouTube Live",
                        label = "YouTube Main Channel",
                        serverUrl = "rtmp://a.rtmp.youtube.com/live2",
                        rawStreamKey = "live_sample_yt88",
                        isEnabled = true
                    )
                )
                rtmpDao.insert(
                    RtmpDestinationEntity.createSecure(
                        platformName = "Twitch",
                        label = "Twitch Gaming Hub",
                        serverUrl = "rtmp://live.twitch.tv/app/",
                        rawStreamKey = "live_sample_tw77",
                        isEnabled = true
                    )
                )
                rtmpDao.insert(
                    RtmpDestinationEntity.createSecure(
                        platformName = "Custom RTMP",
                        label = "Private RTMP Ingest",
                        serverUrl = "rtmp://stream.lxgstudio.internal/live",
                        rawStreamKey = "live_secure_key_9921",
                        isEnabled = false
                    )
                )
            }

            val sceneDao = database.sceneDao()
            // Ensure default scenes exist
            sceneDao.insert(
                SceneEntity(
                    id = 1,
                    name = "Camera Primary",
                    isCameraEnabled = true,
                    cameraLens = "BACK",
                    isScreenEnabled = false,
                    isPipEnabled = false,
                    textOverlay = "@LXG_Studio",
                    showTimestamp = true,
                    showWatermark = true
                )
            )
            sceneDao.insert(
                SceneEntity(
                    id = 2,
                    name = "Screen + Cam PiP",
                    isCameraEnabled = true,
                    cameraLens = "FRONT",
                    isScreenEnabled = true,
                    isPipEnabled = true,
                    textOverlay = "LIVE GAMEPLAY",
                    showTimestamp = true,
                    showWatermark = true
                )
            )
            sceneDao.insert(
                SceneEntity(
                    id = 3,
                    name = "Intermission / BRB",
                    isCameraEnabled = false,
                    isScreenEnabled = false,
                    isPipEnabled = false,
                    textOverlay = "STREAM STARTING SHORTLY",
                    showTimestamp = false,
                    showWatermark = true
                )
            )
        }
    }
}
