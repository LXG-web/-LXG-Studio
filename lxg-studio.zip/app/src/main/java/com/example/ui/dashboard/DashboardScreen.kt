package com.example.ui.dashboard

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Podcasts
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DestinationEntity
import com.example.data.model.RecordingEntity
import com.example.engine.RecordingStatus
import com.example.engine.StreamStatus
import com.example.ui.MainViewModel
import com.example.ui.NavigationTab
import com.example.ui.components.AudioMeterView
import com.example.ui.theme.StudioAudioGreen
import com.example.ui.theme.StudioAudioYellow
import com.example.ui.theme.StudioCyanAccent
import com.example.ui.theme.StudioDarkBg
import com.example.ui.theme.StudioLiveRed
import com.example.ui.theme.StudioPurplePrimary
import com.example.ui.theme.StudioPurpleSecondary
import com.example.ui.theme.StudioRecordAmber
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceBorder
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    onNavigateTab: (NavigationTab) -> Unit
) {
    val streamStatus by viewModel.streamStatus.collectAsState()
    val recordingStatus by viewModel.recordingStatus.collectAsState()
    val telemetry by viewModel.telemetry.collectAsState()
    val audioMeter by viewModel.audioMeter.collectAsState()
    val settings by viewModel.streamSettings.collectAsState()
    val destinations by viewModel.destinations.collectAsState()
    val recordings by viewModel.recordings.collectAsState()
    val storageInfo by viewModel.storageInfo.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()

    val isLive = streamStatus == StreamStatus.LIVE
    val isRecording = recordingStatus == RecordingStatus.RECORDING

    val context = androidx.compose.ui.platform.LocalContext.current
    val permissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    fun checkAndExecute(action: () -> Unit) {
        val cam = androidx.core.content.ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.CAMERA
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        val mic = androidx.core.content.ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (!cam || !mic) {
            permissionLauncher.launch(
                arrayOf(
                    android.Manifest.permission.CAMERA,
                    android.Manifest.permission.RECORD_AUDIO
                )
            )
        } else {
            action()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioDarkBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Status Notification snack if any
            statusMessage?.let { msg ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                    border = androidx.compose.foundation.BorderStroke(1.dp, StudioCyanAccent.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sensors,
                            contentDescription = null,
                            tint = StudioCyanAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = msg,
                            fontSize = 12.sp,
                            color = StudioTextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "DISMISS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = StudioCyanAccent,
                            modifier = Modifier
                                .clickable { viewModel.clearStatusMessage() }
                                .padding(4.dp)
                        )
                    }
                }
            }
        }

        // Hero Stream Deck Controls (Go Live & Start Recording)
        item {
            HeroControlPanel(
                isLive = isLive,
                isRecording = isRecording,
                streamStatus = streamStatus,
                durationText = telemetry.formattedDuration,
                onToggleLive = { checkAndExecute { viewModel.toggleStreaming() } },
                onToggleRecord = { checkAndExecute { viewModel.toggleRecording() } },
                onOpenStudio = { onNavigateTab(NavigationTab.STUDIO) }
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Telemetry Metrics Grid (Resolution, FPS, Bitrate, Storage)
        item {
            Text(
                text = "STREAM TELEMETRY",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = StudioTextMuted,
                letterSpacing = 1.2.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = "RESOLUTION",
                    value = settings.resolutionLabel.substringBefore(" "),
                    subtitle = "${settings.resolutionWidth}x${settings.resolutionHeight}",
                    icon = Icons.Default.Videocam,
                    accentColor = StudioPurplePrimary,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(NavigationTab.SETTINGS) }
                )
                MetricCard(
                    title = "FRAME RATE",
                    value = "${if (isLive) telemetry.currentFps else settings.fps} FPS",
                    subtitle = "Standard Smooth",
                    icon = Icons.Default.FlashOn,
                    accentColor = StudioCyanAccent,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(NavigationTab.SETTINGS) }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = "BITRATE",
                    value = if (isLive) "${telemetry.currentBitrateKbps}k" else "${settings.videoBitrateKbps}k",
                    subtitle = if (isLive) "Active stream" else "Target rate",
                    icon = Icons.Default.Sensors,
                    accentColor = if (isLive) StudioAudioGreen else StudioRecordAmber,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(NavigationTab.SETTINGS) }
                )
                MetricCard(
                    title = "STORAGE",
                    value = String.format(Locale.US, "%.1f GB", storageInfo.freeGb),
                    subtitle = "Free space",
                    icon = Icons.Default.Bookmark,
                    accentColor = StudioTextSecondary,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(NavigationTab.RECORDINGS) }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Live Audio Console
        item {
            Text(
                text = "AUDIO MONITOR",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = StudioTextMuted,
                letterSpacing = 1.2.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            AudioMeterView(
                audioMeter = audioMeter,
                isMuted = settings.isMicMuted,
                gainPercent = settings.micGainPercent,
                onToggleMute = { viewModel.toggleMicMute() },
                onGainChanged = { viewModel.setMicGain(it) }
            )
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Connected Broadcast Platforms
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "BROADCAST DESTINATIONS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioTextMuted,
                    letterSpacing = 1.2.sp
                )
                Text(
                    text = "Manage (${destinations.size})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioCyanAccent,
                    modifier = Modifier
                        .clickable { onNavigateTab(NavigationTab.DESTINATIONS) }
                        .padding(4.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    if (destinations.isEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "No streaming destinations configured.",
                                fontSize = 13.sp,
                                color = StudioTextMuted
                            )
                        }
                    } else {
                        destinations.take(3).forEach { dest ->
                            DestinationRowMini(
                                destination = dest,
                                onToggle = { viewModel.toggleDestination(dest) }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Quick Studio Actions
        item {
            Text(
                text = "QUICK STUDIO ACTIONS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = StudioTextMuted,
                letterSpacing = 1.2.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionButton(
                    label = "Studio Canvas",
                    icon = Icons.Default.Videocam,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(NavigationTab.STUDIO) }
                )
                QuickActionButton(
                    label = "Flip Camera",
                    icon = Icons.Default.Cameraswitch,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.toggleCameraLens() }
                )
                QuickActionButton(
                    label = "Save Clip",
                    icon = Icons.Default.History,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.captureReplayBuffer() }
                )
                QuickActionButton(
                    label = "Settings",
                    icon = Icons.Default.Settings,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(NavigationTab.SETTINGS) }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Recent Recordings
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "RECENT RECORDINGS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioTextMuted,
                    letterSpacing = 1.2.sp
                )
                Text(
                    text = "View All (${recordings.size})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioCyanAccent,
                    modifier = Modifier
                        .clickable { onNavigateTab(NavigationTab.RECORDINGS) }
                        .padding(4.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            if (recordings.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = null,
                            tint = StudioTextMuted,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No recordings yet",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = StudioTextSecondary
                        )
                        Text(
                            text = "Tap 'Start Recording' or record in Studio to capture clips",
                            fontSize = 12.sp,
                            color = StudioTextMuted
                        )
                    }
                }
            } else {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(recordings.take(5)) { rec ->
                        RecentRecordingCard(
                            recording = rec,
                            onPlay = { viewModel.openPlayback(rec) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HeroControlPanel(
    isLive: Boolean,
    isRecording: Boolean,
    streamStatus: StreamStatus,
    durationText: String,
    onToggleLive: () -> Unit,
    onToggleRecord: () -> Unit,
    onOpenStudio: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("dashboard_hero_panel"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(
            1.5.dp,
            if (isLive) StudioLiveRed.copy(alpha = 0.8f) else StudioSurfaceBorder
        )
    ) {
        Column(
            modifier = Modifier.padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (isLive) "ON AIR BROADCASTING" else "BROADCAST CONTROL",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isLive) StudioLiveRed else StudioCyanAccent,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = if (isLive) "Broadcasting Live" else "Studio Ready",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = StudioTextPrimary
                    )
                }

                if (isLive) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(StudioLiveRed.copy(0.2f))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = durationText,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = StudioLiveRed
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Main Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // GO LIVE Button
                Button(
                    onClick = onToggleLive,
                    modifier = Modifier
                        .weight(1.3f)
                        .height(52.dp)
                        .testTag("go_live_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isLive) StudioLiveRed else StudioPurplePrimary
                    )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = if (isLive) Icons.Default.Stop else Icons.Default.Radio,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isLive) "END STREAM" else "GO LIVE",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            letterSpacing = 0.8.sp,
                            color = Color.White
                        )
                    }
                }

                // RECORD Button
                OutlinedButton(
                    onClick = onToggleRecord,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("start_recording_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (isRecording) StudioRecordAmber.copy(0.2f) else Color.Transparent
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.5.dp,
                        if (isRecording) StudioRecordAmber else StudioSurfaceBorder
                    )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                            contentDescription = null,
                            tint = if (isRecording) StudioRecordAmber else StudioTextPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isRecording) "STOP REC" else "RECORD",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (isRecording) StudioRecordAmber else StudioTextPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clickable { onClick() }
            .testTag("metric_${title.lowercase()}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioTextMuted,
                    letterSpacing = 1.sp
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                color = StudioTextPrimary
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = StudioTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun DestinationRowMini(
    destination: DestinationEntity,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(if (destination.isEnabled) StudioAudioGreen else StudioTextMuted)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = destination.label,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = StudioTextPrimary
                )
                Text(
                    text = destination.platformName,
                    fontSize = 11.sp,
                    color = StudioTextMuted
                )
            }
        }

        Switch(
            checked = destination.isEnabled,
            onCheckedChange = { onToggle() },
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = StudioPurplePrimary,
                uncheckedThumbColor = StudioTextMuted,
                uncheckedTrackColor = StudioSurface
            ),
            modifier = Modifier.testTag("toggle_${destination.id}")
        )
    }
}

@Composable
private fun QuickActionButton(
    label: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clickable { onClick() }
            .testTag("quick_${label.lowercase().replace(" ", "_")}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = StudioCyanAccent,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = StudioTextSecondary,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun RecentRecordingCard(
    recording: RecordingEntity,
    onPlay: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(160.dp)
            .clickable { onPlay() }
            .testTag("recent_rec_${recording.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(StudioSurface),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Play",
                    tint = StudioCyanAccent,
                    modifier = Modifier.size(32.dp)
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Black.copy(0.7f))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${recording.durationMs / 1000}s",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = recording.title,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = StudioTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${recording.resolution} • ${recording.fps}fps",
                fontSize = 10.sp,
                color = StudioTextMuted
            )
        }
    }
}
