package com.example.ui.studio

import android.app.Activity
import android.content.Context
import android.media.projection.MediaProjectionManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.ScreenShare
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.StopScreenShare
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.model.SceneEntity
import com.example.engine.RecordingStatus
import com.example.engine.StreamStatus
import com.example.ui.MainViewModel
import com.example.ui.theme.StudioAudioGreen
import com.example.ui.theme.StudioCyanAccent
import com.example.ui.theme.StudioDarkBg
import com.example.ui.theme.StudioLiveRed
import com.example.ui.theme.StudioPurplePrimary
import com.example.ui.theme.StudioRecordAmber
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceBorder
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StudioScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val streamStatus by viewModel.streamStatus.collectAsState()
    val recordingStatus by viewModel.recordingStatus.collectAsState()
    val telemetry by viewModel.telemetry.collectAsState()
    val settings by viewModel.streamSettings.collectAsState()
    val scenes by viewModel.scenes.collectAsState()
    val selectedScene by viewModel.selectedScene.collectAsState()
    val cameraSelector by viewModel.cameraSelector.collectAsState()
    val isScreenCaptureActive by viewModel.isScreenCaptureActive.collectAsState()

    val currentScene = selectedScene ?: scenes.firstOrNull() ?: SceneEntity(
        id = 1,
        name = "Camera Primary",
        isCameraEnabled = true,
        textOverlay = "@LXG_Studio",
        showTimestamp = true,
        showWatermark = true
    )

    var showOverlayEditor by remember { mutableStateOf(false) }
    var showChatOverlay by remember { mutableStateOf(false) }

    // MediaProjection screen capture launcher
    val screenCaptureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.streamEngine.setScreenCaptureState(true)
        }
    }

    // Permission launcher for Camera & Mic
    var hasCameraPermission by remember { mutableStateOf(false) }
    var hasMicPermission by remember { mutableStateOf(false) }
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        hasCameraPermission = permissions[android.Manifest.permission.CAMERA] == true
        hasMicPermission = permissions[android.Manifest.permission.RECORD_AUDIO] == true
    }

    LaunchedEffect(Unit) {
        val cam = ContextCompat.checkSelfPermission(context, android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED
        val mic = ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED
        hasCameraPermission = cam
        hasMicPermission = mic
        if (!cam || !mic) {
            permissionLauncher.launch(
                arrayOf(
                    android.Manifest.permission.CAMERA,
                    android.Manifest.permission.RECORD_AUDIO
                )
            )
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioDarkBg)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Scene Selector Tabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "STUDIO CANVAS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = StudioTextMuted,
                letterSpacing = 1.2.sp
            )
            Text(
                text = "Scene: ${currentScene.name}",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = StudioCyanAccent
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Scene Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(scenes) { scene ->
                val isSelected = scene.id == currentScene.id
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.selectScene(scene) },
                    label = {
                        Text(
                            text = scene.name,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = StudioPurplePrimary,
                        selectedLabelColor = Color.White,
                        containerColor = StudioSurfaceElevated,
                        labelColor = StudioTextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSelected,
                        borderColor = if (isSelected) StudioPurplePrimary else StudioSurfaceBorder
                    ),
                    modifier = Modifier.testTag("scene_chip_${scene.id}")
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Main Studio Canvas Viewport (OBS-like Aspect Ratio 16:9)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .testTag("studio_canvas_viewport"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Black),
            border = androidx.compose.foundation.BorderStroke(
                1.5.dp,
                if (streamStatus == StreamStatus.LIVE) StudioLiveRed else StudioSurfaceBorder
            )
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Background video feed (Camera or Screen)
                if (currentScene.isScreenEnabled || isScreenCaptureActive) {
                    // Screen Share Source Display
                    ScreenCaptureDisplay(
                        isCapturing = isScreenCaptureActive,
                        onRequestCapture = {
                            val mediaProjectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                            screenCaptureLauncher.launch(mediaProjectionManager.createScreenCaptureIntent())
                        }
                    )
                } else if (currentScene.isCameraEnabled && hasCameraPermission) {
                    // Real CameraX preview
                    AndroidView(
                        factory = { ctx ->
                            val previewView = PreviewView(ctx)
                            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                            cameraProviderFuture.addListener({
                                val cameraProvider = cameraProviderFuture.get()
                                val preview = Preview.Builder().build().also {
                                    it.setSurfaceProvider(previewView.surfaceProvider)
                                }
                                try {
                                    cameraProvider.unbindAll()
                                    cameraProvider.bindToLifecycle(
                                        lifecycleOwner,
                                        cameraSelector,
                                        preview
                                    )
                                } catch (e: Exception) {
                                    // bind error fallback
                                }
                            }, ContextCompat.getMainExecutor(ctx))
                            previewView
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    // Standby / Intermission Canvas
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.radialGradient(
                                    listOf(StudioSurfaceElevated, Color.Black)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.VideocamOff,
                                contentDescription = null,
                                tint = StudioTextMuted,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "SCENE: ${currentScene.name}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = StudioTextSecondary
                            )
                            Text(
                                text = "Intermission / Standby Feed",
                                fontSize = 11.sp,
                                color = StudioTextMuted
                            )
                        }
                    }
                }

                // Picture-in-Picture (PiP) Window if active
                if (currentScene.isPipEnabled && hasCameraPermission) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(12.dp)
                            .size(width = 110.dp, height = 75.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.5.dp, StudioCyanAccent, RoundedCornerShape(8.dp))
                            .background(Color.Black)
                    ) {
                        AndroidView(
                            factory = { ctx ->
                                PreviewView(ctx).apply {
                                    scaleType = PreviewView.ScaleType.FILL_CENTER
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(4.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.Black.copy(0.7f))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "CAM PiP",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = StudioCyanAccent
                            )
                        }
                    }
                }

                // Overlay Layer: Watermark (Top Left)
                if (currentScene.showWatermark) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(12.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.Black.copy(0.6f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(StudioCyanAccent)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = currentScene.watermarkText,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }

                // Overlay Layer: Timecode (Top Right)
                if (currentScene.showTimestamp) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(12.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.Black.copy(0.6f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        val timecode = remember { SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) }
                        Text(
                            text = if (streamStatus == StreamStatus.LIVE) telemetry.formattedDuration else timecode,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (streamStatus == StreamStatus.LIVE) StudioLiveRed else StudioTextPrimary
                        )
                    }
                }

                // Overlay Layer: Lower-Third Text Overlay (Bottom Left)
                if (currentScene.textOverlay.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(12.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(StudioPurplePrimary.copy(alpha = 0.85f))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = currentScene.textOverlay,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                // Simulated Chat/Alerts Overlay (Bottom Right if enabled)
                if (showChatOverlay) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(bottom = 12.dp, end = if (currentScene.isPipEnabled) 130.dp else 12.dp)
                            .width(150.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(0.75f))
                            .padding(8.dp)
                    ) {
                        Column {
                            Text(
                                text = "STREAM ALERTS",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Black,
                                color = StudioCyanAccent
                            )
                            Text(
                                text = "★ Alex subscribed!",
                                fontSize = 9.sp,
                                color = StudioAudioGreen,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Sarah: Stream looks crisp!",
                                fontSize = 9.sp,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Canvas Overlays Toolbar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { showOverlayEditor = true },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StudioTextPrimary),
                    border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder),
                    modifier = Modifier.testTag("edit_overlays_button")
                ) {
                    Icon(imageVector = Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Overlays", fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = { showChatOverlay = !showChatOverlay },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (showChatOverlay) StudioCyanAccent else StudioTextSecondary
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (showChatOverlay) StudioCyanAccent else StudioSurfaceBorder
                    )
                ) {
                    Icon(imageVector = Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Chat HUD", fontSize = 12.sp)
                }
            }

            // Quick Camera Lens Switch
            IconButton(
                onClick = { viewModel.toggleCameraLens() },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(StudioSurfaceElevated)
                    .border(1.dp, StudioSurfaceBorder, CircleShape)
                    .testTag("studio_flip_camera")
            ) {
                Icon(
                    imageVector = Icons.Default.Cameraswitch,
                    contentDescription = "Switch Camera",
                    tint = StudioCyanAccent,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Studio Master Control Dock
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("studio_master_control_dock"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
            border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "MASTER BROADCAST CONTROLS",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioTextMuted,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Go Live Button
                    Button(
                        onClick = { viewModel.toggleStreaming() },
                        modifier = Modifier
                            .weight(1.3f)
                            .height(48.dp)
                            .testTag("studio_go_live_btn"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (streamStatus == StreamStatus.LIVE) StudioLiveRed else StudioPurplePrimary
                        )
                    ) {
                        Icon(
                            imageVector = if (streamStatus == StreamStatus.LIVE) Icons.Default.Stop else Icons.Default.Radio,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (streamStatus == StreamStatus.LIVE) "END STREAM" else "GO LIVE",
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp
                        )
                    }

                    // Record Button
                    OutlinedButton(
                        onClick = { viewModel.toggleRecording() },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("studio_record_btn"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (recordingStatus == RecordingStatus.RECORDING) StudioRecordAmber.copy(0.2f) else Color.Transparent
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (recordingStatus == RecordingStatus.RECORDING) StudioRecordAmber else StudioSurfaceBorder
                        )
                    ) {
                        Icon(
                            imageVector = if (recordingStatus == RecordingStatus.RECORDING) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                            contentDescription = null,
                            tint = if (recordingStatus == RecordingStatus.RECORDING) StudioRecordAmber else StudioTextPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (recordingStatus == RecordingStatus.RECORDING) "STOP" else "REC",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (recordingStatus == RecordingStatus.RECORDING) StudioRecordAmber else StudioTextPrimary
                        )
                    }

                    // Mic Mute Quick Toggle
                    IconButton(
                        onClick = { viewModel.toggleMicMute() },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(StudioSurface)
                            .border(1.dp, StudioSurfaceBorder, RoundedCornerShape(10.dp))
                    ) {
                        Icon(
                            imageVector = if (settings.isMicMuted) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = "Mute",
                            tint = if (settings.isMicMuted) StudioLiveRed else StudioAudioGreen
                        )
                    }
                }
            }
        }
    }

    // Overlay Customization Dialog
    if (showOverlayEditor) {
        OverlayEditorDialog(
            currentScene = currentScene,
            onDismiss = { showOverlayEditor = false },
            onSave = { textOverlay, showWatermark, showTimestamp ->
                viewModel.updateSceneOverlays(currentScene.id, textOverlay, showWatermark, showTimestamp)
                showOverlayEditor = false
            }
        )
    }
}

@Composable
private fun ScreenCaptureDisplay(
    isCapturing: Boolean,
    onRequestCapture: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(16.dp)
        ) {
            Icon(
                imageVector = if (isCapturing) Icons.Default.ScreenShare else Icons.Default.StopScreenShare,
                contentDescription = null,
                tint = if (isCapturing) StudioCyanAccent else StudioTextMuted,
                modifier = Modifier.size(36.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (isCapturing) "Screen Projection Active" else "Screen Capture Source",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = StudioTextPrimary
            )
            Text(
                text = if (isCapturing) "Mirroring device display to stream" else "MediaProjection requires user permission",
                fontSize = 11.sp,
                color = StudioTextMuted
            )
            if (!isCapturing) {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onRequestCapture,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioCyanAccent)
                ) {
                    Text(
                        text = "Grant Screen Capture",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
            }
        }
    }
}

@Composable
private fun OverlayEditorDialog(
    currentScene: SceneEntity,
    onDismiss: () -> Unit,
    onSave: (String, Boolean, Boolean) -> Unit
) {
    var textOverlay by remember { mutableStateOf(currentScene.textOverlay) }
    var showWatermark by remember { mutableStateOf(currentScene.showWatermark) }
    var showTimestamp by remember { mutableStateOf(currentScene.showTimestamp) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioSurfaceElevated,
        title = {
            Text(
                text = "Scene Overlays & Graphics",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = StudioTextPrimary
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "LOWER-THIRD TEXT / SOCIAL HANDLE",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioTextMuted
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = textOverlay,
                    onValueChange = { textOverlay = it },
                    placeholder = { Text("@LXG_Studio | Live from mobile", fontSize = 12.sp) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("overlay_text_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StudioPurplePrimary,
                        unfocusedBorderColor = StudioSurfaceBorder,
                        focusedTextColor = StudioTextPrimary,
                        unfocusedTextColor = StudioTextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Studio Watermark", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = StudioTextPrimary)
                        Text(text = "Display 'LXG STUDIO LIVE' badge", fontSize = 11.sp, color = StudioTextMuted)
                    }
                    Switch(
                        checked = showWatermark,
                        onCheckedChange = { showWatermark = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = StudioPurplePrimary)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Timecode HUD", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = StudioTextPrimary)
                        Text(text = "Show broadcast duration counter", fontSize = 11.sp, color = StudioTextMuted)
                    }
                    Switch(
                        checked = showTimestamp,
                        onCheckedChange = { showTimestamp = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = StudioPurplePrimary)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(textOverlay, showWatermark, showTimestamp) },
                colors = ButtonDefaults.buttonColors(containerColor = StudioPurplePrimary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Apply Overlays", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = StudioTextSecondary)
            }
        }
    )
}
